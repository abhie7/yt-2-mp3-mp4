import { createSlice } from "@reduxjs/toolkit"

// Define initial state
const initialState = {
  jdText: "",
  bssData: {},
  parentJobTitles: [],
  parentSkills: [],
  currentlySelectedJobTitles: [],
  currentlySelectedSkills: [],
  selectedNumberLabels: [0, 3, 5],
  selectedVariations: {}, // { parentItem: [variations] }
  regeneratedStrings: [],
}

// Create a slice
const bssGeneratorSlice = createSlice({
  name: "bssGenerator",
  initialState,
  reducers: {
    resetState: () => initialState, // Add resetState action
    setJdText: (state, action) => {
      state.jdText = action.payload
    },
    setBssFromJD: (state, action) => {
      state.bssData = action.payload
      state.parentJobTitles = action.payload.extracted_job_titles || []
      state.parentSkills = action.payload.extracted_skills || []
      state.currentlySelectedJobTitles =
        action.payload.default_keys?.job_titles || []
      state.currentlySelectedSkills = action.payload.default_keys?.skills || []
    },
    clearJdText: (state) => {
      state.jdText = ""
    },
    addJobTitle: (state, action) => {
      state.parentJobTitles.push(action.payload)
    },
    removeJobTitle: (state, action) => {
      state.parentJobTitles = state.parentJobTitles.filter(
        (title) => title !== action.payload
      )
      state.currentlySelectedJobTitles =
        state.currentlySelectedJobTitles.filter(
          (title) => title !== action.payload
        )
    },
    addSkill: (state, action) => {
      state.parentSkills.push(action.payload)
    },
    removeSkill: (state, action) => {
      state.parentSkills = state.parentSkills.filter(
        (skill) => skill !== action.payload
      )
      state.currentlySelectedSkills = state.currentlySelectedSkills.filter(
        (skill) => skill !== action.payload
      )
    },
    selectTitle: (state, action) => {
      state.currentlySelectedJobTitles.push(action.payload)
    },
    deselectTitle: (state, action) => {
      state.currentlySelectedJobTitles =
        state.currentlySelectedJobTitles.filter(
          (title) => title !== action.payload
        )
    },
    selectSkill: (state, action) => {
      state.currentlySelectedSkills.push(action.payload)
    },
    deselectSkill: (state, action) => {
      state.currentlySelectedSkills = state.currentlySelectedSkills.filter(
        (skill) => skill !== action.payload
      )
    },
    toggleNumberLabel: (state, action) => {
      const label = action.payload
      if (state.selectedNumberLabels.includes(label)) {
        state.selectedNumberLabels = state.selectedNumberLabels.filter(
          (item) => item !== label
        )
      } else {
        state.selectedNumberLabels.push(label)
      }
    },
    setSelectedVariations: (state, action) => {
      const { parentItem, variations } = action.payload
      state.selectedVariations[parentItem] = variations
    },
    setRegeneratedStrings: (state, action) => {
      state.regeneratedStrings = action.payload
    },
  },
})

// Export actions
export const {
  resetState,
  setJdText,
  setBssFromJD,
  clearJdText,
  addJobTitle,
  removeJobTitle,
  addSkill,
  removeSkill,
  selectTitle,
  deselectTitle,
  selectSkill,
  deselectSkill,
  toggleNumberLabel,
  setSelectedVariations,
  setRegeneratedStrings,
} = bssGeneratorSlice.actions

// Export reducer
export default bssGeneratorSlice.reducer
