import { configureStore } from "@reduxjs/toolkit"
import bssGeneratorSlice from "./slice"

const store = configureStore({
  reducer: {
    bssGenerator: bssGeneratorSlice,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false, // Disable the serializable state invariant middleware
    }),
})

export default store
