import React from "react"

function Divider() {
  return <hr className='divider' />
}

export default Divider
