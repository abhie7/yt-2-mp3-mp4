import React, { useState } from "react"
import InputForm from "../InputForm/InputForm"
import Button from "../Button/Button"
import { useDispatch, useSelector } from "react-redux"
import {
  setJdText,
  setBssFromJD,
  clearJdText,
  resetState,
} from "../../redux/slice"
import { generateStringsFromJD } from "../../api/generateStringsFromJD"

function LeftPane() {
  const dispatch = useDispatch()
  const jdText = useSelector((state) => state.bssGenerator.jdText) // Accessing state
  const [localJdText, setLocalJdText] = useState(jdText) // Local state to handle input

  const generateBssFromJD = async () => {
    try {
      const response = await generateStringsFromJD(localJdText)
      console.log("Response for Generate BTN: ", response)
      dispatch(setBssFromJD(response)) // Dispatch the generated data to Redux
    } catch (error) {
      console.error("Error extracting data:", error)
    }
  }

  return (
    <>
      <InputForm
        jdText={localJdText}
        setJdText={setLocalJdText}
        onEnterPress={generateBssFromJD}
      />
      <div className='button-group d-flex gap-2'>
        <Button
          text='Clear Context&nbsp;'
          color='secondary'
          onClick={() => {
            setLocalJdText("")
            dispatch(resetState()) // Clear everything and reset state
          }}
          width='30%'
          icon='bi-x-lg'
        />
        <Button
          text='Generate Boolean Strings&nbsp;'
          color='primary'
          onClick={() => {
            dispatch(resetState()) // Clear everything and reset state
            generateBssFromJD()
          }}
          width='70%'
          icon='bi-stars'
        />
      </div>
    </>
  )
}

export default LeftPane
