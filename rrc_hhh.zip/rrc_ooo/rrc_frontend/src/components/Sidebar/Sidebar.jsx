import React, { useState } from "react"
import {
  CSidebar,
  CSidebarHeader,
  CSidebarBrand,
  CNavItem,
  CSidebarNav,
  CNavTitle,
  CNavGroup,
  CBadge,
  CSidebarToggler,
} from "@coreui/react"
import {
  FaTachometerAlt,
  FaPuzzlePiece,
  FaCloudDownloadAlt,
  FaLayerGroup,
} from "react-icons/fa"

function Sidebar() {
  const [sidebarShow, setSidebarShow] = useState(true)

  return (
    <CSidebar
      show={sidebarShow}
      onShowChange={(val) => setSidebarShow(val)}
      className='border-end'
    >
      <CSidebarHeader className='border-bottom'>
        <CSidebarBrand>CoreUI</CSidebarBrand>
      </CSidebarHeader>
      <CSidebarNav>
        <CNavTitle>Nav Title</CNavTitle>
        <CNavItem href='#'>
          <FaTachometerAlt className='nav-icon' /> Nav item
        </CNavItem>
        <CNavItem href='#'>
          <FaTachometerAlt className='nav-icon' /> With badge{" "}
          <CBadge color='primary ms-auto'>NEW</CBadge>
        </CNavItem>
        <CNavGroup
          toggler={
            <>
              <FaPuzzlePiece className='nav-icon' /> Nav dropdown
            </>
          }
        >
          <CNavItem href='#'>
            <span className='nav-icon'>
              <span className='nav-icon-bullet'></span>
            </span>{" "}
            Nav dropdown item
          </CNavItem>
          <CNavItem href='#'>
            <span className='nav-icon'>
              <span className='nav-icon-bullet'></span>
            </span>{" "}
            Nav dropdown item
          </CNavItem>
        </CNavGroup>
        <CNavItem href='https://coreui.io'>
          <FaCloudDownloadAlt className='nav-icon' /> Download CoreUI
        </CNavItem>
        <CNavItem href='https://coreui.io/pro/'>
          <FaLayerGroup className='nav-icon' /> Try CoreUI PRO
        </CNavItem>
      </CSidebarNav>
      <CSidebarHeader className='border-top'>
        <CSidebarToggler onClick={() => setSidebarShow(!sidebarShow)} />
      </CSidebarHeader>
    </CSidebar>
  )
}

export default Sidebar
