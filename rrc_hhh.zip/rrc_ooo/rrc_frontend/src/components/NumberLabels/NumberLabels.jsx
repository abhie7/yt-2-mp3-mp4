import React from "react"
import { useSelector, useDispatch } from "react-redux"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import { toggleNumberLabel } from "../../redux/slice"

function NumberLabels() {
  const numberLabels = [0, 3, 5, 7, 10]
  const dispatch = useDispatch()
  const checkedItems = useSelector(
    (state) => state.bssGenerator.selectedNumberLabels
  )

  console.log("currentNumberLabels:", checkedItems)

  const handleCheckboxChange = (label) => {
    dispatch(toggleNumberLabel(label))
  }

  return (
    <div className='d-flex align-items-center flex-nowrap'>
      <p className='mb-0 flex-shrink-0 container-title custom-title'>
        Add related # of keywords:&nbsp;
        <TooltipIcon
          iconClass='bi-question-circle'
          tooltipText='Choose how many related keywords you want to include in the Boolean string. Selecting a higher number will broaden the search to include more relevant terms.'
          placement='bottom'
        />
      </p>

      <div className='dynamic-list-container d-flex flex-wrap gap-2 flex-grow-1 ms-2'>
        {numberLabels.map((label, index) => (
          <div
            key={index}
            className='d-inline-flex align-items-center label-font rounded-1 py-1 px-2'
          >
            <label
              className='custom-checkbox-container d-flex align-items-center gap-2 me-1'
              style={{ cursor: "pointer" }}
            >
              <input
                type='checkbox'
                className='custom-checkbox'
                checked={checkedItems.includes(label)} // Check if the label is in the checkedItems
                onChange={() => handleCheckboxChange(label)} // Handle checkbox change
              />
              <span className='custom-checkbox-checkmark'></span>
              <p style={{ fontSize: "0.9rem" }} className='m-0 p-0'>
                {label}
              </p>
            </label>
          </div>
        ))}
      </div>
    </div>
  )
}

export default NumberLabels
