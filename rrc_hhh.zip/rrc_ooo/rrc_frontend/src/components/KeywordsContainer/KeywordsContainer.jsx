import React, { useState } from "react"
import DynamicListContainer from "../DynamicListContainer/DynamicListContainer"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import VariationModal from "../Modal/Modal"
import { useSelector, useDispatch } from "react-redux"
import {
  addSkill,
  removeSkill,
  selectSkill,
  deselectSkill,
} from "../../redux/slice"
import PuffLoader from "react-spinners/PuffLoader"

function KeywordsContainer({ loading }) {
  const [modalShow, setModalShow] = useState(false)
  const dispatch = useDispatch()

  const parentSkills = useSelector(
    (state) => state.bssGenerator.parentSkills ?? []
  )

  const defaultCheckedSkills = useSelector(
    (state) => state.bssGenerator.bssData?.default_keys?.skills ?? []
  )
  const currentlySelectedSkills = useSelector(
    (state) => state.bssGenerator.currentlySelectedSkills
  )
  const selectedVariations = useSelector(
    (state) => state.bssGenerator.selectedVariations
  )

  // console.log("parentSkills:", parentSkills)
  // console.log("defaultCheckedSkills:", defaultCheckedSkills)
  // console.log("currentlySelectedSkills:", currentlySelectedSkills)
  console.log("selectedVariations:", selectedVariations)

  const handleAddItem = (newItem) => {
    dispatch(addSkill(newItem))
  }

  const handleRemoveItem = (item) => {
    dispatch(removeSkill(item))
  }

  const handleCheckboxChange = (item, isChecked) => {
    if (isChecked) {
      dispatch(selectSkill(item))
    } else {
      dispatch(deselectSkill(item))
    }
  }

  return (
    <div className='d-flex align-items-start flex-nowrap'>
      <p className='mb-0 flex-shrink-0 container-title custom-title'>
        Keywords:&nbsp;
        <TooltipIcon
          iconClass='bi-question-circle'
          tooltipText="Select the keywords that are important for the job role. These keywords will be included in the Boolean string to refine the search results. You can add more keywords by clicking the '+' button."
          placement={"bottom"}
        />
      </p>
      {loading ? (
        <div className='flex-grow-1 ms-2 mb-1 d-flex justify-content-center align-items-center'>
          <PuffLoader color='#007bff' />
        </div>
      ) : parentSkills.length > 0 ? (
        <DynamicListContainer
          className='flex-grow-1 ms-2'
          items={parentSkills}
          placeholder='Add keyword...'
          tooltipText='Add keyword'
          defaultCheckedItems={defaultCheckedSkills}
          currentlyCheckedItems={currentlySelectedSkills}
          onAddItem={handleAddItem}
          onRemoveItem={handleRemoveItem}
          onCheckboxChange={handleCheckboxChange}
        />
      ) : (
        <div className='flex-grow-1 ms-2 mb-1'>
          <span className='placeholder-text'>
            Extracted keywords will be displayed here...
          </span>
        </div>
      )}
      <TooltipIcon
        iconClass='bi-database-fill-add modal-btn text-light rounded'
        tooltipText='View Related Keywords'
        placement='left'
        onClick={() => setModalShow(true)}
      />
      <VariationModal
        show={modalShow}
        onHide={() => setModalShow(false)}
        items={parentSkills}
        currentlySelectedItems={currentlySelectedSkills}
        type='skills'
      />
    </div>
  )
}

export default KeywordsContainer
