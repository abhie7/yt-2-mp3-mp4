import React, { useState, useEffect } from "react"
import PropTypes from "prop-types"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import AddItemForm from "../AddItemForm/AddItemForm"

function DynamicListContainer({
  items = [],
  defaultCheckedItems = [],
  placeholder = "Enter item",
  tooltipText = "Add item",
  className = "",
  onAddItem,
  onRemoveItem,
  onCheckboxChange,
}) {
  const [itemList, setItemList] = useState(items)
  const [checkedItems, setCheckedItems] = useState(defaultCheckedItems)
  const [isAdding, setIsAdding] = useState(false)
  const [hoveredIndex, setHoveredIndex] = useState(null)

  // Synchronize the checkedItems with the parent if it changes
  useEffect(() => {
    setCheckedItems(defaultCheckedItems)
  }, [defaultCheckedItems])

  const handleRemoveItem = (index) => {
    const item = itemList[index]
    const updatedList = itemList.filter((_, i) => i !== index)
    setItemList(updatedList)
    onRemoveItem(item)
  }

  const handleAddItem = (newItem) => {
    if (newItem) {
      const updatedList = [...itemList, newItem]
      setItemList(updatedList)
      onAddItem(newItem)
    }
    setIsAdding(false)
  }

  // Handle checkbox selection change
  const handleCheckboxChange = (item) => {
    let updatedCheckedItems
    if (checkedItems.includes(item)) {
      // If item is already checked, uncheck it
      updatedCheckedItems = checkedItems.filter((i) => i !== item)
      onCheckboxChange(item, false)
    } else {
      // If item is not checked, check it
      updatedCheckedItems = [...checkedItems, item]
      onCheckboxChange(item, true)
    }
    setCheckedItems(updatedCheckedItems)
  }

  return (
    <div
      className={`dynamic-list-container d-flex flex-wrap gap-2 ${className}`}
    >
      {itemList.map((item, index) => (
        <div
          key={index}
          className='d-inline-flex align-items-center label-font rounded-1 px-1 py-1'
          onMouseEnter={() => setHoveredIndex(index)}
          onMouseLeave={() => setHoveredIndex(null)}
        >
          <label
            className='custom-checkbox-container d-flex align-items-center'
            style={{ cursor: "pointer" }}
          >
            <input
              type='checkbox'
              className='custom-checkbox'
              checked={checkedItems.includes(item)} // Mark the checkbox as checked if it's in the checkedItems list
              onChange={() => handleCheckboxChange(item)} // Toggle the checkbox state
            />
            <span className='custom-checkbox-checkmark me-2'></span>
            <span style={{ lineHeight: 0 }}>{item}</span>
          </label>
          <div
            className='d-flex align-items-center ms-2'
            style={{
              cursor: "pointer",
              width: "1rem",
              height: "1rem",
            }}
            onClick={() => handleRemoveItem(index)}
          >
            {hoveredIndex === index ? (
              <TooltipIcon
                iconClass='bi bi-dash-circle text-danger'
                tooltipText='Remove'
              />
            ) : null}
          </div>
        </div>
      ))}
      <div className='d-inline-add align-items-center'>
        {isAdding ? (
          <AddItemForm onAdd={handleAddItem} placeholder={placeholder} />
        ) : (
          <div onClick={() => setIsAdding(true)}>
            <TooltipIcon
              iconClass='bi-plus-circle'
              tooltipText={tooltipText}
              placement='top'
            />
          </div>
        )}
      </div>
    </div>
  )
}

DynamicListContainer.propTypes = {
  items: PropTypes.arrayOf(PropTypes.string).isRequired,
  defaultCheckedItems: PropTypes.arrayOf(PropTypes.string),
  placeholder: PropTypes.string,
  tooltipText: PropTypes.string,
  className: PropTypes.string,
  onAddItem: PropTypes.func.isRequired,
  onRemoveItem: PropTypes.func.isRequired,
  onCheckboxChange: PropTypes.func.isRequired,
}

export default DynamicListContainer
