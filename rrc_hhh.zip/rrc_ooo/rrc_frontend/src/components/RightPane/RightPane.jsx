import React from "react"
import NumberLabels from "../NumberLabels/NumberLabels"
import BooleanStringContainer from "../BooleanStringContainer/BooleanStringContainer"
import Divider from "../Divider/Divider"
import JobTitleContainer from "../JobTitleContainer/JobTitleContainer"
import KeywordsContainer from "../KeywordsContainer/KeywordsContainer"
import XraySearch from "../XraySearch/XraySearch"
import Button from "../Button/Button"
import { useSelector, useDispatch } from "react-redux"
import { generateStrings } from "../../api/generateStrings"
import { setRegeneratedStrings } from "../../redux/slice"

function RightPane() {
  const currentlySelectedSkills = useSelector(
    (state) => state.bssGenerator.currentlySelectedSkills
  )
  const currentlySelectedJobTitles = useSelector(
    (state) => state.bssGenerator.currentlySelectedJobTitles
  )
  const selectedVariations = useSelector(
    (state) => state.bssGenerator.selectedVariations
  )
  const currentNumberLabels = useSelector(
    (state) => state.bssGenerator.selectedNumberLabels
  )

  const dispatch = useDispatch()
  const regenerateBss = async () => {
    const payload = {
      currentlySelectedJobTitles, // Ensure this field is correct
      currentlySelectedSkills,
      selectedVariations,
      currentNumberLabels,
    }
    try {
      const response = await generateStrings(payload)
      console.log("Response for Re-generate BTN: ", response)
      dispatch(setRegeneratedStrings(response)) // Dispatch the generated data to Redux
    } catch (error) {
      console.error("Error extracting data:", error)
    }
  }


  return (
    <div className='right-pane-container flex-grow-1'>
      <JobTitleContainer />
      <Divider />
      <KeywordsContainer />
      <Divider />
      <div className='d-flex align-items-center'>
        <NumberLabels />
        <div className='vertical-divider mx-3'></div>{" "}
        {/* Add vertical divider */}
        <Button
          text='Re-generate'
          color='primary'
          onClick={regenerateBss}
          className='ms-2'
          icon='bi-arrow-repeat ms-1'
        />
      </div>
      <Divider />
      <XraySearch />
      <BooleanStringContainer />
    </div>
  )
}

export default RightPane
