import React from "react"
import PropTypes from "prop-types"
import Modal from "react-bootstrap/Modal"
import Button from "react-bootstrap/Button"
import PuffLoader from "react-spinners/PuffLoader"

function ResumeModal({ show, onHide, resumes, loading }) {
  const downloadFile = (filePath) => {
    const link = document.createElement("a")
    link.href = filePath // Assuming filePath is a valid URL
    link.download = filePath.split("/").pop()
    link.click()
  }

  return (
    <Modal show={show} onHide={onHide} size='lg'>
      <Modal.Header closeButton>
        <Modal.Title>Matched Resumes ({resumes.length})</Modal.Title>
      </Modal.Header>
      <Modal.Body style={{ maxHeight: "400px", overflowY: "auto" }}>
        {loading ? (
          <div className='d-flex justify-content-center'>
            <PuffLoader color='#36d7b7' />
          </div>
        ) : resumes.length > 0 ? (
          <ul>
            {resumes.map((resume, index) => (
              <li
                key={index}
                className='d-flex justify-content-between align-items-center mb-2'
              >
                <span>{resume.resume}</span>
                <div>
                  <Button
                    variant='link'
                    href={`http://localhost:6969/file-view?filepath=${resume.resume}`}
                    target='_blank'
                    rel='noopener noreferrer'
                  >
                    View
                  </Button>
                  <Button
                    variant='link'
                    onClick={() => downloadFile(resume.resume)}
                  >
                    Download
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p>No matching resumes found.</p>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Button variant='secondary' onClick={onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

ResumeModal.propTypes = {
  show: PropTypes.bool.isRequired,
  onHide: PropTypes.func.isRequired,
  resumes: PropTypes.array.isRequired,
}

export default ResumeModal
