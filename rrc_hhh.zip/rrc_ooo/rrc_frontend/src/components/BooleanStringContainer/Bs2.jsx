import React, { useState, useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import Button from "../Button/Button"
import ResumeModal from "../ResumeModal/ResumeModal"
import { getMatchingResumes } from "../../api/getMatchingResumes"

function BooleanStringContainer() {
  const dispatch = useDispatch()
  const bssData = useSelector((state) => state.bssGenerator.bssData)
  const regeneratedStrings = useSelector(
    (state) => state.bssGenerator.regeneratedStrings
  )

  const [booleanStrings, setBooleanStrings] = useState([])
  const [editIndex, setEditIndex] = useState(null)
  const [editText, setEditText] = useState("")
  const [showModal, setShowModal] = useState(false)
  const [matchedResumes, setMatchedResumes] = useState([])

  const bss_1 = bssData?.bss_pipeline_1?.bss || ""
  const bss_2 = bssData?.bss_pipeline_2?.bss || ""
  const bss_3 = bssData?.bss_pipeline_3?.bss || ""

  const updatedBsc1 = regeneratedStrings?.bss_pipeline_1?.bsc || []

  useEffect(() => {
    setBooleanStrings([bss_1, bss_2, bss_3])
  }, [bssData])

  useEffect(() => {
    if (regeneratedStrings) {
      setBooleanStrings([
        regeneratedStrings?.bss_pipeline_1?.bss || bss_1,
        regeneratedStrings?.bss_pipeline_2?.bss || bss_2,
        regeneratedStrings?.bss_pipeline_3?.bss || bss_3,
      ])
    }
  }, [regeneratedStrings])

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text)
    alert(`Copied ${text.length} characters!`)
  }

  const handleSearch = async (booleanString, updatedBsc) => {
    try {
      if (!booleanString) {
        console.warn("No boolean string provided for search.")
        return
      }
      const data = await getMatchingResumes(updatedBsc) // Use updated bsc directly
      setMatchedResumes(data?.matching_resumes || [])
      setShowModal(true)
    } catch (error) {
      console.error("Error fetching resumes:", error.message)
    }
  }

  return (
    <div className='boolean-string-container'>
      <div className='boolean-strings-wrapper px-0'>
        {booleanStrings.map((string, index) => (
          <div
            key={index}
            className='boolean-string-container-item position-relative'
          >
            <div className='boolean-string rounded p-2 mb-2'>
              <p className='me-4'>{string}</p>
              <div className='button-container'>
                <TooltipIcon
                  iconClass='bi bi-copy'
                  tooltipText={`Copy ${string.length} characters`}
                  placement='left'
                  className='tooltip-icon-container'
                  onClick={() => handleCopy(string)}
                />
                <TooltipIcon
                    iconClass='bi bi-pencil'
                  tooltipText='Edit String'
                  placement='left'
                  className='tooltip-icon-container'
                  onClick={() => setEditIndex(index)}
                />
                <TooltipIcon
                  iconClass='bi bi-search'
                  tooltipText='Search for resumes'
                  placement='left'
                  onClick={() => handleSearch(string, updatedBsc1)}
                />
                <ResumeModal
                  show={showModal}
                  onHide={() => setShowModal(false)}
                  resumes={matchedResumes}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default BooleanStringContainer
