import React, { useState, useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import Button from "../Button/Button"
import ResumeModal from "../ResumeModal/ResumeModal"
import { getMatchingResumes } from "../../api/getMatchingResumes"
import PuffLoader from "react-spinners/PuffLoader"

function BooleanStringContainer() {
  const dispatch = useDispatch()
  const bssData = useSelector((state) => state.bssGenerator.bssData)
  const regeneratedStrings = useSelector(
    (state) => state.bssGenerator.regeneratedStrings
  )

  // Use optional chaining to safely access bss properties
  const bss_1 = bssData?.bss_pipeline_1?.bss || ""
  const bss_2 = bssData?.bss_pipeline_2?.bss || ""
  const bss_3 = bssData?.bss_pipeline_3?.bss || ""

  const updatedBsc1 = regeneratedStrings?.bss_pipeline_1?.bsc || []
  const updatedBsc2 = regeneratedStrings?.bss_pipeline_2?.bsc || []
  const updatedBsc3 = regeneratedStrings?.bss_pipeline_3?.bsc || []

  const [booleanStrings, setBooleanStrings] = useState([bss_1, bss_2, bss_3])
  const [editIndex, setEditIndex] = useState(null)
  const [editText, setEditText] = useState("")
  const [showModal, setShowModal] = useState(false)
  const [matchedResumes, setMatchedResumes] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    setBooleanStrings([bss_1, bss_2, bss_3])
  }, [bssData])

  useEffect(() => {
    if (regeneratedStrings) {
      setBooleanStrings([
        regeneratedStrings?.bss_pipeline_1?.bss || bss_1,
        regeneratedStrings?.bss_pipeline_2?.bss || bss_2,
        regeneratedStrings?.bss_pipeline_3?.bss || bss_3,
      ])
    }
  }, [regeneratedStrings])

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text)
    alert(`Copied ${text.length} characters!`)
  }

  // const handleEdit = (index) => {
  //   setEditIndex(index)
  //   setEditText(booleanStrings[index])
  // }

  const handleSearch = async (booleanString, updatedBsc) => {
    try {
      if (!booleanString) {
        console.warn("No boolean string provided for search.")
        return
      }

      // Validate and structure `updatedBsc` as a list of lists
      const formattedBsc =
        Array.isArray(updatedBsc) && Array.isArray(updatedBsc[0])
          ? updatedBsc
          : [updatedBsc]

      setLoading(true)
      const data = await getMatchingResumes(formattedBsc) // Use validated payload
      setMatchedResumes(data?.matching_resumes || [])
      setShowModal(true)
    } catch (error) {
      console.error("Error fetching resumes:", error.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSave = (index) => {
    const updatedStrings = [...booleanStrings]
    updatedStrings[index] = editText
    setBooleanStrings(updatedStrings)
    setEditIndex(null)
  }

  const formatBooleanString = (booleanString) => {
    if (typeof booleanString !== "string") {
      console.warn("Expected a string but received:", booleanString)
      return null
    }

    const regex = /(".*?"|\(|\)|AND|OR)/g
    return booleanString.split(regex).map((item, index) => {
      if (item === "AND" || item === "OR") {
        return (
          <span key={index} className='boolean-operator'>
            {item}
          </span>
        )
      } else if (item === "(" || item === ")") {
        return (
          <span key={index} className='boolean-parenthesis'>
            {item}
          </span>
        )
      } else if (item.trim() !== "") {
        return (
          <span key={index} className='boolean-item'>
            {item}
          </span>
        )
      } else {
        return null
      }
    })
  }

  return (
    <div key={booleanStrings.join()} className='boolean-string-container'>
      <div className='boolean-strings-wrapper px-0'>
        {booleanStrings.map((string, index) => (
          <div
            key={index}
            className='boolean-string-container-item position-relative'
          >
            {editIndex === index ? (
              <div className='boolean-string rounded p-2 mb-2'>
                <input
                  type='text'
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  className='form-control'
                />
                <Button
                  text='Save&nbsp;'
                  color='primary'
                  onClick={() => handleSave(index)}
                  icon='bi-arrow-right'
                />
              </div>
            ) : (
              <div className='boolean-string rounded p-2 mb-2'>
                <p className='me-4'>{formatBooleanString(string)}</p>
                <div className='button-container'>
                  <TooltipIcon
                    iconClass='bi bi-copy'
                    tooltipText={`Copy ${string.length} characters`}
                    placement='left'
                    className='tooltip-icon-container'
                    onClick={() => handleCopy(string)}
                  />
                  <TooltipIcon
                    iconClass='bi bi-pencil'
                    tooltipText='Edit String'
                    placement='left'
                    className='tooltip-icon-container'
                    onClick={() => setEditIndex(index)}
                  />
                  <>
                    <TooltipIcon
                      iconClass='bi bi-search'
                      tooltipText='Search for resumes'
                      placement='left'
                      onClick={() => {
                        const updatedBscArray = [
                          updatedBsc1,
                          updatedBsc2,
                          updatedBsc3,
                        ]
                        handleSearch(string, updatedBscArray[index])
                      }}
                    />

                    <ResumeModal
                      show={showModal}
                      onHide={() => setShowModal(false)}
                      resumes={matchedResumes}
                      loading={loading}
                    />
                  </>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

export default BooleanStringContainer
