import React, { useState } from 'react';
import LeftPane from './LeftPane/LeftPane.jsx';
import RightPane from './RightPane/RightPane.jsx';

function MainContent() {
    const [extractedSkills, setExtractedSkills] = useState([]);
    const [extractedJobTitles, setExtractedJobTitles] = useState([]);
    const [skillVariations, setSkillVariations] = useState([]);
    const [jobTitleVariations, setJobTitleVariations] = useState([]);

    return (
        <div className='main-content d-flex w-100 h-100'>
            <div className='left-pane '>
                <LeftPane
                    setExtractedSkills={setExtractedSkills}
                    setExtractedJobTitles={setExtractedJobTitles}
                    setSkillVariations={setSkillVariations}
                    setJobTitleVariations={setJobTitleVariations}
                />
            </div>

            <div className='right-pane flex-grow-1 h-100 d-flex'>
                <RightPane
                    extractedSkills={extractedSkills}
                    extractedJobTitles={extractedJobTitles}
                    skillVariations={skillVariations}
                    jobTitleVariations={jobTitleVariations}
                />
            </div>
        </div>
    );
}

export default MainContent;