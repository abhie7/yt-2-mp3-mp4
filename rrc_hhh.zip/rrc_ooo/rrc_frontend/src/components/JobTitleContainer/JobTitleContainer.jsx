import React, { useState } from "react"
import DynamicListContainer from "../DynamicListContainer/DynamicListContainer"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import VariationModal from "../Modal/Modal"
import { useSelector, useDispatch } from "react-redux"
import {
  addJobTitle,
  removeJobTitle,
  selectTitle,
  deselectTitle,
} from "../../redux/slice"
import PuffLoader from "react-spinners/PuffLoader"

function JobTitleContainer({ loading }) {
  const [modalShow, setModalShow] = useState(false)
  const dispatch = useDispatch()

  const parentJobTitles = useSelector(
    (state) => state.bssGenerator.parentJobTitles ?? []
  )

  const defaultCheckedTitles = useSelector(
    (state) => state.bssGenerator.bssData?.default_keys?.job_titles ?? []
  )
  const currentlySelectedJobTitles = useSelector(
    (state) => state.bssGenerator.currentlySelectedJobTitles
  )
  const selectedVariations = useSelector(
    (state) => state.bssGenerator.selectedVariations
  )

  // console.log("parentJobTitles:", parentJobTitles)
  // console.log("defaultCheckedTitles:", defaultCheckedTitles)
  // console.log("currentlySelectedJobTitles:", currentlySelectedJobTitles)
  console.log("selectedVariations:", selectedVariations)

  const handleAddItem = (newItem) => {
    dispatch(addJobTitle(newItem))
  }

  const handleRemoveItem = (item) => {
    dispatch(removeJobTitle(item))
  }

  const handleCheckboxChange = (item, isChecked) => {
    if (isChecked) {
      dispatch(selectTitle(item))
    } else {
      dispatch(deselectTitle(item))
    }
  }

  return (
    <div className='d-flex align-items-start flex-nowrap'>
      <p className='mb-0 flex-shrink-0 container-title custom-title'>
        Job Titles:&nbsp;
        <TooltipIcon
          iconClass='bi-question-circle'
          tooltipText='Select the job titles relevant to your search. These titles will be included in the Boolean string to broaden the search for similar roles. You can add or remove job titles by checking the boxes.'
          placement='bottom'
        />
      </p>
      {loading ? (
        <div className='flex-grow-1 ms-2 mb-1 d-flex justify-content-center align-items-center'>
          <PuffLoader color='#007bff' />
        </div>
      ) : parentJobTitles.length > 0 ? (
        <DynamicListContainer
          className='flex-grow-1 ms-2 me-2'
          items={parentJobTitles}
          placeholder='Add job title...'
          tooltipText='Add job title'
          defaultCheckedItems={defaultCheckedTitles}
          currentlyCheckedItems={currentlySelectedJobTitles}
          onAddItem={handleAddItem}
          onRemoveItem={handleRemoveItem}
          onCheckboxChange={handleCheckboxChange}
        />
      ) : (
        <div className='flex-grow-1 ms-2 mb-1'>
          <span className='placeholder-text'>
            Extracted job titles will be displayed here...
          </span>
        </div>
      )}
      <TooltipIcon
        iconClass='bi-database-fill-add modal-btn text-light rounded'
        tooltipText='View Related Job Titles'
        placement='left'
        onClick={() => setModalShow(true)}
      />
      <VariationModal
        show={modalShow}
        onHide={() => setModalShow(false)}
        items={parentJobTitles}
        currentlySelectedItems={currentlySelectedJobTitles}
        type='jobTitles'
      />
    </div>
  )
}

export default JobTitleContainer