import React, { useState } from "react"; // Import useState here
import {
  CNavbar,
  CContainer,
  CNavbarBrand,
  CNavbarToggler,
  CCollapse,
  CNavbarNav,
  CNavItem,
  CNavLink,
  CDropdown,
  CDropdownToggle,
  CDropdownMenu,
  CDropdownItem,
  CDropdownDivider,
} from "@coreui/react";

function Navbar() {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <CNavbar expand="lg" colorScheme="dark" >
        <CContainer fluid>
          <CNavbarBrand href="#">
            <i className="bi bi-person-hearts"> </i>Boolean Search String
            Generator
          </CNavbarBrand>
          <CNavbarToggler
            aria-label="Toggle navigation"
            aria-expanded={visible}
            onClick={() => setVisible(!visible)}
          />
          <CCollapse className="navbar-collapse " visible={visible}>
            <CNavbarNav className="d-flex align-items-center gap-3" >
              <CNavItem>
                <CNavLink href="#" active>
                  Home
                </CNavLink>
              </CNavItem>
              <CNavItem>
                <CNavLink href="#">Features</CNavLink>
              </CNavItem>
              <CDropdown variant="nav-item" popper={true} alignment="end">
                <CDropdownToggle className="p-0" caret={false}>
                  <i
                    className="bi bi-person-circle p-0"
                    style={{ fontSize: "1.4rem" }}
                  ></i>
                </CDropdownToggle>
                <CDropdownMenu className="px-2">
                  <CDropdownItem href="#">
                    <i className="bi bi-person-fill m-2 text-custom-primary"> </i>
                    Profile
                  </CDropdownItem>
                  <CDropdownItem href="#">
                    <i className="bi bi-gear-fill m-2 text-custom-primary"> </i>Settings
                  </CDropdownItem>
                  <CDropdownDivider />
                  <CDropdownItem href="#">
                    <i className="bi bi-x-circle-fill m-2 text-custom-primary"> </i>Logout
                  </CDropdownItem>
                </CDropdownMenu>
              </CDropdown>
            </CNavbarNav>
          </CCollapse>
        </CContainer>
      </CNavbar>
    </>
  );
}

export default Navbar;
