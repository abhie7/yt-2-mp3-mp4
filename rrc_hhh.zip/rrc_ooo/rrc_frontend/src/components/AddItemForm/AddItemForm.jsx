import React, { useState, useRef, useEffect } from "react"
import PropTypes from "prop-types"

const AddItemForm = ({ onAdd, placeholder = "Enter item" }) => {
  const [newItem, setNewItem] = useState("")
  const formRef = useRef()

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (formRef.current && !formRef.current.contains(event.target)) {
        onAdd(null) // close the form without adding
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [onAdd])

  const handleAdd = () => {
    if (newItem.trim()) {
      onAdd(newItem.trim())
      setNewItem("")
    } else {
      onAdd(null) // close form without adding empty item
    }
  }

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      handleAdd()
    }
  }

  return (
    <div ref={formRef} className='add-form d-flex align-items-center'>
      <input
        type='text'
        value={newItem}
        onChange={(e) => setNewItem(e.target.value)}
        onKeyPress={handleKeyPress}
        className='form-control add-form-input rounded-start-1'
        placeholder={placeholder}
      />
      <button
        className='btn btn-success rounded-end-1 add-btn'
        onClick={handleAdd}
      >
        <i className='bi-check2-circle'></i>
      </button>
    </div>
  )
}

AddItemForm.propTypes = {
  onAdd: PropTypes.func.isRequired,
  placeholder: PropTypes.string,
}

export default AddItemForm
