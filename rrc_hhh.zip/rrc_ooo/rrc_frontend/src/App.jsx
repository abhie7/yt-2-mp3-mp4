import React from "react"
import { Container } from "react-bootstrap"
import Navbar from "./components/Navbar/Navbar"
// import Sidebar from "./components/Sidebar/Sidebar"
import MainContent from "./components/MainContent"

// import scss
import "./scss/style.scss"
import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap/dist/js/bootstrap.bundle.min.js"

function App() {
  return (
    <div className='app d-flex flex-column'>
      <Navbar />
      {/* <Sidebar /> */}
      <Container fluid className='main-container p-0 flex-grow-1 w-100'>
        <MainContent />
      </Container>
    </div>
  )
}

export default App
