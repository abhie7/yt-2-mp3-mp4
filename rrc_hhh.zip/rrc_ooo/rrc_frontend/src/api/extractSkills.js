const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

export const extractSkills = async (jdText) => {
  const response = await fetch(`${API_BASE_URL}/extract_skills`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ jd_text: jdText }),
  });

  return response.json();
};