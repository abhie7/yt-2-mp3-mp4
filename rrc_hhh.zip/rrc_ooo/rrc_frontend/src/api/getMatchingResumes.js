const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

export const getMatchingResumes = async (boolean_search_combination) => {
  try {
    const response = await fetch(`${API_BASE_URL}/get-matching-resume`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ bsc: boolean_search_combination }),
    });

    if (!response.ok) {
      // Handle HTTP errors
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Error in getMatchingResumes:", error);
    throw error;
  }
};
