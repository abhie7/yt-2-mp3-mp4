const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

export const generateBooleanSearchString = async (
  selectedSkills,
  selectedJobTitles,
  variations,
  numLabels
) => {
  try {
    const maxVariations = Math.max(...numLabels);
    const limitedVariations = {};
    for (const skill in variations) {
      if (Array.isArray(variations[skill])) {
        limitedVariations[skill] = variations[skill].slice(0, maxVariations);
      } else {
        limitedVariations[skill] = [];
      }
    }

    const payload = {
      selected_skills: selectedSkills,
      selected_job_titles: selectedJobTitles,
      variations: limitedVariations,
      num_of_keyword_variations: numLabels,
    };

    const response = await fetch(`${API_BASE_URL}/generate_bss`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Error generating boolean search string:", error);
  }
};