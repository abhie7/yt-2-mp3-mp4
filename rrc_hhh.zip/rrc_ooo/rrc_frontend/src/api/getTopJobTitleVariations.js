const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

export const getTopJobTitleVariations = async (jobTitle) => {
  const response = await fetch(`${API_BASE_URL}/get_top_job_title_variations`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ job_title: jobTitle }),
  });
  return response.json();
};