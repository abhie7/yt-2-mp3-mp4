const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

export const getTopSkillVariations = async (skill) => {
  const response = await fetch(`${API_BASE_URL}/get_top_skill_variations`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ skill }),
  });
  return response.json();
};
