document.addEventListener("DOMContentLoaded", () => {
  const extractSkillsBtn = document.getElementById("extract-skills-btn")
  const jdTextarea = document.querySelector(".jd-textarea")
  const extractedSkillsContainer = document.querySelector(
      ".extracted-skills-container"
  )
  const skillCardsContainer = document.querySelector(
      ".skill-cards-container2"
  )
  const selectedSkillsContainer = document.querySelector(
      ".selected-skills-container"
  )
  const variationsContainer = document.querySelector(".variations-container")
  const bssOutputContainer = document.querySelector(".bss-output")
  const bssCharCountContainer = document.getElementById("bss-char-count")
  const addCustomSkillBtn = document.getElementById("add-custom-skill-btn")
  const addSkillPopup = document.getElementById("add-skill-popup")
  const cancelAddSkillBtn = document.getElementById("cancel-add-skill")
  const confirmAddSkillBtn = document.getElementById("confirm-add-skill")
  const customSkillInput = document.getElementById("custom-skill-input")
  const copyButton = document.getElementById("copy-bss")
  const bssLinkedin = document.getElementById('bss-linkedin')
  const selectVariationsBtn = document.getElementById("select-variations-btn")
  const selectJobTitlesBtn = document.getElementById("select-job-titles-btn")

  const addedSkills = new Set()
  const sessionArray = { mainSkills: [], variations: {}, jobTitles: {} }
  let currentMode = "variations" // Default mode
  let currentSelectedSkill = null // Track the currently selected skill

  const prevPageBtn = document.getElementById("prev-page-btn")
  const nextPageBtn = document.getElementById("next-page-btn")
  const paginationInfo = document.getElementById("pagination-info")

  const addVariationBtn = document.getElementById("add-variation-btn")
  const addVariationInputContainer = document.getElementById(
      "add-variation-input-container"
  )
  const newVariationInput = document.getElementById("new-variation-input")
  const confirmAddVariationBtn = document.getElementById(
      "confirm-add-variation-btn"
  )

  let currentPage = 1
  const itemsPerPage = 15

  // Event Listeners
  addCustomSkillBtn.addEventListener("click", showAddSkillPopup)
  cancelAddSkillBtn.addEventListener("click", hideAddSkillPopup)
  confirmAddSkillBtn.addEventListener("click", confirmAddSkill)
  copyButton.addEventListener("click", copyBss)
  extractSkillsBtn.addEventListener("click", extractSkills)
  extractedSkillsContainer.addEventListener("click", handleSkillRemoval)
  prevPageBtn.addEventListener("click", () => changePage(-1))
  nextPageBtn.addEventListener("click", () => changePage(1))
  // selectVariationsBtn.addEventListener("click", () => {
  //     toggleMode("variations")
  //     if (currentSelectedSkill) {
  //         fetchSkillData(
  //             currentSelectedSkill,
  //             document.querySelector(
  //                 `.skill-card[data-skill="${currentSelectedSkill}"]`
  //             )
  //         )
  //     }
  // })
  bssLinkedin.addEventListener('click', ()=>{
      window.open(`https://www.google.com/search?q=${bssOutputContainer.textContent} site://linkedin.com/in`, '_blank')
  })
  
  

  // selectJobTitlesBtn.addEventListener("click", () => {
  //     toggleMode("job_titles")
  //     if (currentSelectedSkill) {
  //         fetchSkillData(
  //             currentSelectedSkill,
  //             document.querySelector(
  //                 `.skill-card[data-skill="${currentSelectedSkill}"]`
  //             )
  //         )
  //     }
  // })

  // addVariationBtn.addEventListener("click", () => {
  //     addVariationInputContainer.style.display = "flex"
  //     newVariationInput.focus()
  // })

  // confirmAddVariationBtn.addEventListener("click", () => {
  //     const newVariation = newVariationInput.value.trim()
  //     if (newVariation && currentSelectedSkill) {
  //         addNewVariation(currentSelectedSkill, newVariation)
  //         newVariationInput.value = ""
  //         addVariationInputContainer.style.display = "none"
  //     }
  // })

  // newVariationInput.addEventListener("keydown", (e) => {
  //     if (e.key === "Enter") {
  //         const newVariation = newVariationInput.value.trim()
  //         if (newVariation && currentSelectedSkill) {
  //             addNewVariation(currentSelectedSkill, newVariation)
  //             newVariationInput.value = ""
  //             addVariationInputContainer.style.display = "none"
  //         }
  //     }
  // })

  async function addNewVariation(skill, variation) {
      // Add to frontend
      if (!sessionArray.variations[skill]) {
          sessionArray.variations[skill] = []
      }
      sessionArray.variations[skill].push(variation)
      updateBSSDisplay()

      // Add the new variation to the variations container
      const variationCard = createVariationCard(skill, variation)
      variationsContainer.appendChild(variationCard)

      // Add to backend
      try {
          const response = await fetch("/add_skill_variation", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ skill, variation }),
          })
          const data = await response.json()
          if (data.success) {
              console.log("Variation added successfully")
          } else {
              console.error("Failed to add variation")
          }
      } catch (error) {
          console.error("Error adding variation:", error)
      }
  }

  function showAddSkillPopup() {
      addSkillPopup.style.display = "block"
      customSkillInput.focus()
  }

  function hideAddSkillPopup() {
      addSkillPopup.style.display = "none"
      customSkillInput.value = ""
  }

  function confirmAddSkill() {
      const skillName = customSkillInput.value.trim()
      if (skillName) {
          addCustomSkill(skillName)
          hideAddSkillPopup()
      }
  }

  function addCustomSkill(skill) {
      if (addedSkills.has(skill)) return

      const skillCard = createSkillCard(skill)
      skillCardsContainer.appendChild(skillCard)
  }

  function createSkillCard(skill) {
      const skillCard = document.createElement("div")
      skillCard.className = "skill-card"
      skillCard.setAttribute("data-skill", skill)
      skillCard.innerHTML = `${skill} <button class="add-skill-btn"><i class="ri-add-circle-fill"></i></button>`
      skillCard
          .querySelector(".add-skill-btn")
          .addEventListener("click", (e) => {
              e.stopPropagation() // Prevent the click event from bubbling up to the skill card
              addSkill(skill, skillCard)
          })
      skillCard.setAttribute("tabindex", "0")
      skillCard.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
              addSkill(skill, skillCard)
          }
      })
      skillCard.addEventListener("click", () => addSkill(skill, skillCard))
      return skillCard
  }

  async function extractSkills() {
      const jdText = jdTextarea.value

      // Clear current skills and show loading spinner
      skillCardsContainer.innerHTML = '<div class="loading-spinner"></div>'

      try {
          const response = await fetch("/extract_skills", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ jd_text: jdText }),
          })
          const data = await response.json()
          displayExtractedSkills(data.skills)
      } catch (error) {
          console.error("Error extracting skills:", error)
          // Show error message if extraction fails
          skillCardsContainer.innerHTML =
              '<p style="color: red; text-align: center;">Error extracting skills. Please try again.</p>'
      }
  }

  function displayExtractedSkills(skills) {
      skillCardsContainer.innerHTML = ""
      skills.forEach((skill) => {
          const skillCard = createSkillCard(skill)
          if (addedSkills.has(skill)) {
              markSkillAsAdded(skillCard)
          }
          skillCardsContainer.appendChild(skillCard)
      })
  }

  function markSkillAsAdded(skillCard) {
      skillCard.classList.add("added-skill")
      const addButton = skillCard.querySelector(".add-skill-btn")
      addButton.innerHTML = '<i class="ri-close-circle-fill"></i>'
      addButton.classList.add("remove-skill-btn")
      addButton.classList.remove("add-skill-btn")
  }

  function unmarkSkillAsAdded(skillCard) {
      skillCard.classList.remove("added-skill")
      const removeButton = skillCard.querySelector(".remove-skill-btn")
      removeButton.innerHTML = '<i class="ri-add-circle-fill"></i>'
      removeButton.classList.add("add-skill-btn")
      removeButton.classList.remove("remove-skill-btn")
  }

  function addSkill(skill, skillCard) {
      if (addedSkills.has(skill)) {
          const selectedSkillCard = Array.from(
              document.querySelector(".selected-skills-container").children
          ).find((card) => card.textContent.trim() === skill)
          removeSkill(skill, skillCard, selectedSkillCard)
          return
      }

      addedSkills.add(skill)
      sessionArray.mainSkills.push(skill)
      markSkillAsAdded(skillCard)

      const selectedSkillCard = createSelectedSkillCard(skill, skillCard)
      document
          .querySelector(".selected-skills-container")
          .appendChild(selectedSkillCard)
      adjustSelectedSkillsContainerHeight()
      updateBSSDisplay()

      // Fetch variations by default when a skill is added
      fetchSkillData(skill, selectedSkillCard)
  }

  function createSelectedSkillCard(skill, skillCard) {
      const selectedSkillCard = document.createElement("div")
      selectedSkillCard.className = "skill-card"
      selectedSkillCard.innerHTML = `${skill} <button class="remove-skill-btn"><i class="ri-close-circle-fill"></i></button>`
      selectedSkillCard
          .querySelector(".remove-skill-btn")
          .addEventListener("click", () =>
              removeSkill(skill, skillCard, selectedSkillCard)
          )
      selectedSkillCard.setAttribute("tabindex", "0")
      selectedSkillCard.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
              removeSkill(skill, skillCard, selectedSkillCard)
          }
      })
      selectedSkillCard.addEventListener("click", () =>
          fetchSkillData(skill, selectedSkillCard)
      )
      return selectedSkillCard
  }

  function removeSkill(skill, skillCard, selectedSkillCard) {
      selectedSkillCard.remove()
      addedSkills.delete(skill)
      sessionArray.mainSkills = sessionArray.mainSkills.filter(
          (s) => s !== skill
      )
      delete sessionArray.variations[skill]
      delete sessionArray.jobTitles[skill]
      unmarkSkillAsAdded(skillCard)
      adjustSelectedSkillsContainerHeight()
      updateBSSDisplay()
  }

  const paginationData = {
      variations: [],
      jobTitles: [],
  }
  
  async function fetchSkillData(skill, skillCard) {
      highlightSkillCard(skillCard)
      currentSelectedSkill = skill // Track the currently selected skill

      // Reset to the first page when new data is fetched
      currentPage = 1

      // Show loading spinner
      variationsContainer.innerHTML = '<div class="loading-spinner"></div>'

      try {
          const endpoint =
              currentMode === "variations"
                  ? "/get_skill_variations"
                  : "/get_skill_variations" // Use the same endpoint for both
          const response = await fetch(endpoint, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ skill }),
          })
          const data = await response.json()

          // Retain the existing state of sessionArray
          if (currentMode === "variations") {
              sessionArray.variations[skill] =
                  sessionArray.variations[skill] || []
              paginationData.variations = data.variations || []
              console.log("Fetched variations:", data.variations)
              displayVariations(skill, paginationData.variations)
          } else {
              sessionArray.jobTitles[skill] =
                  sessionArray.jobTitles[skill] || []
              paginationData.jobTitles = data.job_titles || []
              console.log("Fetched job titles:", data.job_titles)
              displayJobTitles(skill, paginationData.jobTitles)
          }

          console.log(
              "Updated sessionArray after fetching data:",
              sessionArray
          )
      } catch (error) {
          console.error(`Error fetching ${currentMode}:`, error)
          variationsContainer.innerHTML =
              '<p style="color: red; text-align: center;">Error fetching data. Please try again.</p>'
      }
  }

  function changePage(direction) {
      currentPage += direction
      if (currentMode === "variations") {
          const totalVariations = paginationData.variations.length
          displayVariations(currentSelectedSkill, paginationData.variations)
          updatePaginationControls(totalVariations)
      } else {
          const totalJobTitles = paginationData.jobTitles.length
          displayJobTitles(currentSelectedSkill, paginationData.jobTitles)
          updatePaginationControls(totalJobTitles)
      }
  }

  function updatePaginationControls(totalItems) {
      const totalPages = Math.ceil(totalItems / itemsPerPage)
      prevPageBtn.disabled = currentPage === 1
      nextPageBtn.disabled = currentPage === totalPages || totalPages === 0
      paginationInfo.textContent = `Page ${currentPage} of ${totalPages}`
  }

  function displayVariations(skill, variations) {
      const start = (currentPage - 1) * itemsPerPage
      const end = start + itemsPerPage
      const paginatedVariations = variations.slice(start, end)

      variationsContainer.innerHTML = ""
      if (paginatedVariations.length === 0) {
          variationsContainer.innerHTML = "<p>No variations found</p>"
      } else {
          paginatedVariations.forEach((variation) => {
              const variationCard = createVariationCard(skill, variation)
              variationsContainer.appendChild(variationCard)
          })
      }

      updatePaginationControls(variations.length)
  }

  function displayJobTitles(skill, jobTitles) {
      const start = (currentPage - 1) * itemsPerPage
      const end = start + itemsPerPage
      const paginatedJobTitles = jobTitles.slice(start, end)

      variationsContainer.innerHTML = ""
      if (paginatedJobTitles.length === 0) {
          variationsContainer.innerHTML = "<p>No job titles found</p>"
      } else {
          paginatedJobTitles.forEach((jobTitle) => {
              const jobTitleCard = createVariationCard(skill, jobTitle)
              variationsContainer.appendChild(jobTitleCard)
          })
      }

      updatePaginationControls(jobTitles.length)
  }

  function createVariationCard(skill, variation) {
      const variationCard = document.createElement("div")
      variationCard.className = "variation-card"
      variationCard.innerHTML = `${variation} <button class="add-variation-btn"><i class="ri-checkbox-circle-line"></i></button>`

      // Check if the variation is already selected
      if (
          sessionArray.variations[skill] &&
          sessionArray.variations[skill].includes(variation)
      ) {
          variationCard.querySelector(".add-variation-btn").innerHTML =
              '<i class="ri-checkbox-circle-fill"></i>'
          variationCard
              .querySelector(".add-variation-btn")
              .classList.add("selected")
      }

      variationCard.addEventListener("click", () =>
          toggleVariation(skill, variation, variationCard)
      )
      variationCard.setAttribute("tabindex", "0")
      variationCard.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
              toggleVariation(skill, variation, variationCard)
          }
      })
      return variationCard
  }

  function toggleVariation(skill, variation, variationCard) {
      if (!sessionArray.variations[skill]) {
          sessionArray.variations[skill] = []
      }

      const index = sessionArray.variations[skill].indexOf(variation)
      const button = variationCard.querySelector(".add-variation-btn")

      if (index > -1) {
          sessionArray.variations[skill].splice(index, 1)
          button.innerHTML = '<i class="ri-checkbox-circle-line"></i>'
          button.classList.remove("selected")
      } else {
          sessionArray.variations[skill].push(variation)
          button.innerHTML = '<i class="ri-checkbox-circle-fill"></i>'
          button.classList.add("selected")
      }

      console.log(
          "Updated sessionArray after toggling variation:",
          sessionArray
      )
      updateBSSDisplay()
  }

  function generateBSS() {
      const bss = sessionArray.mainSkills
          .map((skill) => {
              const variations = sessionArray.variations[skill] || []
              const jobTitles = sessionArray.jobTitles[skill] || []
              const allVariations = [...variations, ...jobTitles]
              return allVariations.length > 0
                  ? `(${[skill, ...allVariations].join(" OR ")})`
                  : skill
          })
          .join(" AND ")
      const bsc = sessionArray.mainSkills
          .map(skill=>{

          })
      console.log("Generated BSS:", bss)
      return bss
  }

  // function updateBSSDisplay() {
  //     const bss = generateBSS()
  //     const bssOutputContainer = document.querySelector(".bss-output")
  //     bssOutputContainer.innerHTML = ""

  //     const bssParts = bss.split(" AND ")
  //     bssParts.forEach((part, index) => {
  //         const skillCard = document.createElement("div")
  //         skillCard.className = "bss-skill-card"
  //         skillCard.textContent = part
  //         bssOutputContainer.appendChild(skillCard)

  //         if (index < bssParts.length - 1) {
  //             const andOperator = document.createElement("div")
  //             andOperator.className = "bss-operator"
  //             andOperator.textContent = " AND "
  //             bssOutputContainer.appendChild(andOperator)
  //         }
  //     })
  // 
  //     adjustBssOutputContainerHeight()
  //     displayBssCharCount(bss)
  // }

  function updateBSSDisplay() {
      const bss = generateBSS()
      bssOutputContainer.innerHTML = bss
      adjustBssOutputContainerHeight()
      displayBssCharCount(bss)
  }

  function copyToClipboard(text) {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand("copy");
      //   console.log("Text copied to clipboard");
      } catch (err) {
      //   console.error("Could not copy text: ", err);
      }
      document.body.removeChild(textarea);
    }
    
  async function copyBss() {
      const bssText = bssOutputContainer.textContent.trim()
      try {
          // await navigator.clipboard.writeText(bssText)
          copyToClipboard(bssText)
          copyButton.style.color = "#fff"
          setTimeout(() => {
              copyButton.style.color = ""
          }, 1000)
      } catch (err) {
          console.error("Failed to copy:", err)
      }
  }

  function handleSkillRemoval(event) {
      if (event.target.closest(".remove-skill-btn")) {
          const skillCard = event.target.closest(".skill-card")
          const skill = skillCard.textContent.trim()
          unmarkSkillAsAdded(skillCard)
          addedSkills.delete(skill)
          sessionArray.mainSkills = sessionArray.mainSkills.filter(
              (s) => s !== skill
          )
          const selectedSkillCard = Array.from(
              selectedSkillsContainer.children
          ).find((card) => card.textContent.trim() === skill)
          if (selectedSkillCard) {
              selectedSkillCard.remove()
          }
          adjustSelectedSkillsContainerHeight()
      }
  }

  function adjustSelectedSkillsContainerHeight() {
      const maxHeight = 15 // Maximum height in vh
      const currentHeight =
          (selectedSkillsContainer.scrollHeight / window.innerHeight) * 100
      selectedSkillsContainer.style.height = `${Math.min(
          currentHeight,
          maxHeight
      )}vh`
  }

  function adjustBssOutputContainerHeight() {
      const maxHeight = 30
      const currentHeight =
          (document.querySelector(".bss-output").scrollHeight /
              window.innerHeight) *
          100
      document.querySelector(".bss-output").style.height = `${Math.min(
          currentHeight,
          maxHeight
      )}vh`
  }

  function displayBssCharCount(bss) {
      const charCount = bss.length
      document.getElementById(
          "bss-char-count"
      ).textContent = `Total characters: ${charCount}`
  }

  function highlightSkillCard(skillCard) {
      // Remove highlight from any previously highlighted card
      const previouslyHighlighted =
          document.querySelector(".highlighted-skill")
      if (previouslyHighlighted) {
          previouslyHighlighted.classList.remove("highlighted-skill")
      }
      // Highlight the new skill card
      skillCard.classList.add("highlighted-skill")
  }

  function unhighlightSkillCard(skillCard) {
      skillCard.classList.remove("highlighted-skill")
  }

  // function toggleMode(mode) {
  //     if (currentMode === mode) return

  //     currentMode = mode
  //     if (mode === "variations") {
  //         selectVariationsBtn.classList.add("selected")
  //         selectVariationsBtn.innerHTML =
  //             'Variations <i class="ri-circle-fill"></i>'
  //         selectJobTitlesBtn.classList.remove("selected")
  //         selectJobTitlesBtn.innerHTML =
  //             'Job Titles <i class="ri-circle-line"></i>'
  //     } else {
  //         selectJobTitlesBtn.classList.add("selected")
  //         selectJobTitlesBtn.innerHTML =
  //             'Job Titles <i class="ri-circle-fill"></i>'
  //         selectVariationsBtn.classList.remove("selected")
  //         selectVariationsBtn.innerHTML =
  //             'Variations <i class="ri-circle-line"></i>'
  //     }

  //     // Clear existing data
  //     variationsContainer.innerHTML = ""

  //     // Fetch data for the currently selected skill when mode is toggled
  //     if (currentSelectedSkill) {
  //         fetchSkillData(
  //             currentSelectedSkill,
  //             document.querySelector(
  //                 `.skill-card[data-skill="${currentSelectedSkill}"]`
  //             )
  //         )
  //     }
  // }
  


  // POPUP
  const searchResume = document.getElementById('bss-search')
searchResume.addEventListener("click", populateFileList)

async function get_matching_resumes() {        
  try{
      const response = await fetch("/get-matching-resume", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ selected_skills: sessionArray.mainSkills, variations: sessionArray.variations }),
      })
      const data = await response.json()
      return data.resumes
      console.log(data)
  } catch(e) {
      console.log(e)
  }
}

async function populateFileList() {
  togglePopup(true);
  const popupHeader = document.getElementById("popup-header")
  const fileListContainer = document.getElementById("file-list");
  fileListContainer.innerHTML = '<div class="loading-spinner"></div>'
  popupHeader.textContent = `Finding Resumes...`

  const filePaths = await get_matching_resumes();
  fileListContainer.innerHTML = "";
  popupHeader.textContent = `Found ${filePaths.length} Resumes`
  filePaths.forEach((filePath, index) => {
      let resumeName = filePath[1]
      filePath = filePath[0]
    const fileItem = document.createElement("div");
    fileItem.className = "file-item";

    const btnItem = document.createElement("div");
    btnItem.className = "btn-item";


    const fileName = document.createElement("span");
    fileName.textContent = resumeName;

    const viewButton = document.createElement("button");
    viewButton.textContent = "View";
    viewButton.onclick = () => viewFile(filePath);

    const downloadButton = document.createElement("button");
    downloadButton.textContent = "Download";
    downloadButton.onclick = () => downloadFile(filePath);

    fileItem.appendChild(fileName);
    btnItem.appendChild(viewButton);
    btnItem.appendChild(downloadButton);
    fileItem.appendChild(btnItem);

    fileListContainer.appendChild(fileItem);
  });

}



// View file content
function viewFile(filePath) {
  window.open(`/file-view?filepath=${filePath}`, '_blank')
  // Add custom logic here to fetch and display file content
}

// Download file
function downloadFile(filePath) {
  const link = document.createElement("a");
  link.href = filePath; // Assuming filePath is a valid URL
  link.download = filePath.split("/").pop();
  link.click();
}
})
