import networkx as nx
import os
import json
import re  # Ensure re is imported
import datetime
import multiprocessing as mp
from collections import Counter
from typing import Union
from functools import reduce
from tqdm import tqdm
import dill as pickle  # Use dill instead of pickle
from app.services.document_parser import DocumentParser

class Node:
    def __init__(self) -> None:
        self.children = {}
        self.is_complete = False
        self.original = None

    def __getitem__(self, key):
        return self.children.get(key)

    def __setitem__(self, key, value):
        self.children[key] = value

    def has_child(self, char):
        return self.children.get(char)

class Trie:
    def __init__(self) -> None:
        self.root = Node()

    def insert(self, word: Union[list[str], str]):
        """
        Arguments:
            word: Union[list[str], str]
        """
        # Handle multiple words
        if isinstance(word, list):
            for w in word:
                self.insert(w)
            return
        # For single word
        node = self.root
        for char in word.lower():
            if re.match(r'\s', char):
                continue
            if not node.has_child(char):
                node[char] = Node()
            node = node[char]

        node.original = word
        node.is_complete = True

    def ingest_from_graph(self, graph):
        skills = [graph.nodes[node]['name'] for node in graph.nodes]
        self.insert(skills)

    def search(self, word, root=None):
        node=root if root else self.root
        word = word.lower()
        for char in word:
            if node.has_child(char):
                node = node[char]
            else:
                return False
        return node

    def _clean_text(self, text):
        text = re.sub(r'[,\'\":\|_]', ' ', text)
        text = re.sub(r'\s\s', ' ', text)
        return text

    def recursive_search(self, words, node, i, temp_result=None, temp_index=None):
        new_node = self.search(words[i], node)
        if not temp_index:
            temp_index = i
        if not new_node: return temp_result, temp_index
        if new_node.is_complete:
            temp_result = new_node.original
            temp_index = i
        if new_node.has_child(words[i+1][0].lower()):
            result = self.recursive_search(words, new_node, i+1, temp_result, temp_index)
            return result
        else:
            return temp_result, temp_index

    def parse_text(self, text):
        text = self._clean_text(text)
        words = text.split()
        for i in range(len(words)):
            splitted = re.split(r'[\\\/]', words[i])
            if splitted: words.extend([s for s in splitted if s])
        words.append('$') #EOS
        n = len(words)
        i = 0
        located_words = set()
        while i<n:
            result, last_index = self.recursive_search(words, self.root, i)
            if result:
                new_i = last_index + 1
                located_words.add(result)
                i = new_i
            else:
                i+=1
        return list(located_words)

    def dfs(self, node:Node, s=""):
        children = []
        if node.children:
            if node.is_complete: children.append(s)
            for child in node.children:
                for c in self.dfs(node[child], s+child):
                    children.append(c)
        else:
            children.append(s)
        return children

    def print_tree(self, word=None):
        root = self.search(word) if word else self.root
        return self.dfs(root)

def debug_print(message, start_time=None):
    current_time = datetime.datetime.now().strftime("%H:%M:%S - %d/%m/%Y")
    if start_time:
        elapsed_time = datetime.datetime.now() - start_time
        message = f"[Graph Service] [{current_time}] {message} - Time Taken: {elapsed_time.total_seconds()} seconds"
    else:
        message = f"[Graph Service] [{current_time}] {message}"
    print(message)

class SkillGraph(nx.MultiDiGraph, Trie):
    def __init__(self):
        nx.MultiDiGraph.__init__(self)
        Trie.__init__(self)

    def clean_skill(self, s: str):
        s = re.sub(r'\(.*?\)', '', s)
        s = s.strip()
        return s

    def _process_file(self, file):
        keys = ['name', 'category', 'subcategory', 'type']
        try:
            with open(file, 'r') as f:
                data = json.load(f)
        except:
            return None

        skillinfo = data['skillInfo']
        main = {
            "name": self.clean_skill(skillinfo['name']),
            "category": skillinfo['category'],
            "subcategory": skillinfo['subcategory'],
            "description": skillinfo['description'],
            "type": skillinfo['type'],
            "key": self.clean_skill(skillinfo['name']).lower(),
            "frequency": 0
        }

        relatedskills = []
        if data.get('relatedSkills'):
            for relatedSkill in data['relatedSkills']:
                temp = {k: v for k, v in [(key, relatedSkill[key]) for key in keys if relatedSkill.get(key)]}
                temp['name'] = self.clean_skill(temp['name'])
                temp['key'] = temp['name'].lower()
                temp['frequency'] = 0
                relatedskills.append(temp)

        return main, relatedskills

    def ingest_skills(self, src, thresh=1):
        start_time = datetime.datetime.now()
        debug_print('Ingesting Skills', start_time)
        files = []
        for dirname, _, filenames in os.walk(src):
            files.extend([os.path.join(dirname, filename) for filename in filenames])

        files = files[:int(len(files) * thresh)]
        results = []

        # Sequential processing of files
        for file in tqdm(files):
            result = self._process_file(file)
            if result:
                results.append(result)

        # Batch graph updates
        for main, relatedskills in results:
            self.add_node(main['key'], **main)
            self.insert(main['name'])

            for rel in relatedskills:
                self.add_node(rel['key'], **rel)
                self.insert(rel['name'])
                self.add_edge(main['key'], rel['key'], relation="related")
                self.add_edge(rel['key'], main['key'], relation="parent")


    def get_siblings(self, node):
        node = node.lower()
        related = Counter()
        try:
            if self.in_degree(node):
                parents = self.predecessors(node)
                for parent in parents:
                    for child in self.successors(parent):
                        if child == node:
                            continue
                        child_node = self.nodes[child]
                        related[child_node['name']] = child_node['frequency']
            for child in self.successors(node):
                child_node = self.nodes[child]
                related[child_node['name']] = child_node['frequency']
        except nx.exception.NetworkXError:
            return []
        return [k for k, c in related.most_common()]

class JobTitleGraph(nx.MultiDiGraph, Trie):
    def __init__(self):
        nx.MultiDiGraph.__init__(self)
        Trie.__init__(self)

    def clean_job_title(self, s: str):
        """Clean and standardize the job title string."""
        s = re.sub(r'\(.*?\)', '', s)
        return s.strip()

    def _process_file(self, file):
        try:
            with open(file, 'r') as f:
                data = json.load(f)
        except Exception as e:
            print(f"Failed to load {file}: {e}")
            return None

        # Fetch job titles from result.job_metadata.titles
        titles = data.get('result', {}).get('job_metadata', {}).get('titles', [])
        job_titles = [self.clean_job_title(title['value']).lower() for title in titles if 'value' in title]

        if not job_titles:
            return None  # Skip files without job title data

        return job_titles

    def ingest_job_titles(self, src, thresh=1):
        start_time = datetime.datetime.now()
        debug_print('Ingesting Job Titles', start_time)

        files = []
        for dirname, _, filenames in os.walk(src):
            files.extend([os.path.join(dirname, filename) for filename in filenames if filename.endswith('.json')])

        files_to_process = files[:int(len(files) * thresh)]
        results = []

        # Sequential processing of files
        for file in tqdm(files_to_process):
            job_titles = self._process_file(file)
            if job_titles:
                results.append(job_titles)

        all_titles = []
        for job_titles in results:
            all_titles.extend(job_titles)

            for job_title in job_titles:
                main = {
                    "name": job_title.title(),
                    "type": "job_title",
                    "key": job_title,
                    "frequency": 0
                }
                self.add_node(main['key'], **main)
                self.insert(main['name'])

            for i, source_title in enumerate(job_titles):
                for target_title in job_titles[i + 1:]:
                    self.add_edge(source_title, target_title, relation="related")
                    self.add_edge(target_title, source_title, relation="related")

        with open('app/data/extracted_job_titles.json', 'w') as outfile:
            json.dump(all_titles, outfile, indent=4)

    def get_siblings(self, node):
        node = node.lower()
        related = Counter()
        try:
            if self.in_degree(node):
                parents = list(self.predecessors(node))
                for parent in parents:
                    for child in self.successors(parent):
                        if child == node:
                            continue
                        child_node = self.nodes[child]
                        related[child_node['name']] += 1
            for child in self.successors(node):
                child_node = self.nodes[child]
                related[child_node['name']] += 1
        except nx.exception.NetworkXError:
            return []
        return [k for k, c in related.most_common()]

    def save_graph_structure(self, filename="app/data/job_title_graph_structure.json"):
        graph_structure = {}
        for node in self.nodes:
            graph_structure[node] = {
                "name": self.nodes[node]["name"],
                "related": list(self.successors(node))
            }
        with open(filename, 'w') as outfile:
            json.dump(graph_structure, outfile, indent=4)


class TestJobTitleGraphPipeline(nx.MultiDiGraph, Trie):
    def __init__(self, data_path: str):
        nx.MultiDiGraph.__init__(self)
        Trie.__init__(self)
        self.ingest_custom_job_titles(data_path)

    def ingest_custom_job_titles(self, data_path: str):
        try:
            with open(data_path, 'r') as file:
                data = json.load(file)
        except Exception as e:
            print(f"Failed to load job title data: {e}")
            return

        for key, value in data.items():
            if not isinstance(value, dict) or "name" not in value or "related" not in value:
                print(f"Skipping invalid entry for key: {key}")
                continue

            main_title = key.lower()
            name = value["name"]
            related_titles = value["related"]

            self.add_node(main_title, name=name, type="job_title", frequency=0)
            self.insert(name)

            for related in related_titles:
                related_key = related.lower()
                self.add_node(related_key, name=related, type="job_title", frequency=0)
                self.insert(related)
                self.add_edge(main_title, related_key, relation="related")
                self.add_edge(related_key, main_title, relation="related")

    def save_graph_structure_pickle(self, filename="app/data/test_job_title_graph.pkl"):
        with open(filename, 'wb') as outfile:
            pickle.dump(self, outfile)


class ResumeGraph(nx.MultiDiGraph):
    def __init__(self, skillgraph: SkillGraph, job_title_graph: Union[JobTitleGraph, TestJobTitleGraphPipeline]):
        super().__init__()
        self.skillgraph = skillgraph
        self.job_title_graph = job_title_graph

    def _process_resume(self, resume_path):
        # Use DocumentParser to parse the document
        parser = DocumentParser(resume_path)
        text = parser.get_cleaned_text()
        skills = self.skillgraph.parse_text(text)
        job_titles = self.job_title_graph.parse_text(text)
        return resume_path, skills, job_titles

    def ingest_resumes(self, resume_paths):
        start_time = datetime.datetime.now()
        debug_print('Ingesting Resumes', start_time)

        if isinstance(resume_paths, list):
            results = [self._process_resume(path) for path in tqdm(resume_paths)]
        else:
            results = [self._process_resume(resume_paths)]

        for resume_path, skills, job_titles in results:
            if resume_path is None:
                continue
            for skill in skills:
                skill = skill.lower()
                self.add_edge(skill, resume_path)
                if skill in self.skillgraph.nodes:
                    self.skillgraph.nodes[skill]['frequency'] += 1
            for title in job_titles:
                title = title.lower()
                self.add_edge(title, resume_path)
                if title in self.job_title_graph.nodes:
                    self.job_title_graph.nodes[title]['frequency'] += 1

        debug_print('Finished Ingesting Resumes', start_time)

    def match_resumes(self, bsc):
        """
        Fetch matching resumes from Graph using Boolean Search Combination
        (a OR b) AND (c OR d)
        requires data in [[a,c],[a,d],[b,c],[b,d]] format, inner array -> AND -- outer array -> OR
        """
        resumes = set()
        for group in bsc:
            try:
                set_collection = [set(self.successors(g.lower())) for g in group]
                resumes = resumes | reduce(set.intersection, set_collection)
            except nx.exception.NetworkXError:
                continue
        return [(resume, os.path.split(resume)[-1]) for resume in resumes]

class GraphPipeline:
    def __init__(self, skillspath= r"f:\Aumu's Folder\Programming\projects\jd_cv\LC_Scrapper\lc_skills_dataset_classified_v1", job_titles_path= r"F:\Aumu's Folder\Programming\projects\rrc_frontend\rrc\Recruitryte_Clone\14_Resume_Keyword_Search_BSS_UI\recruitryte_responses", resumepath= r"F:\Aumu's Folder\Programming\projects\rrc_frontend\rrc\Recruitryte_Clone\Test_Resumes", custom_job_titles_path=None, thresh=1) -> None:
        start_time = datetime.datetime.now()
        debug_print('Initializing GraphPipeline', start_time)
        self.sg = SkillGraph()
        self.jtg = JobTitleGraph() if custom_job_titles_path is None else None
        self.tjtg = TestJobTitleGraphPipeline(custom_job_titles_path) if custom_job_titles_path else None
        self.rg = ResumeGraph(self.sg, self.jtg if self.jtg else self.tjtg)
        self.sg.ingest_skills(skillspath, thresh)
        if self.jtg:
            self.jtg.ingest_job_titles(job_titles_path, thresh)

        resumes = self.fetch_sample_resumes(resumepath, thresh)
        self.rg.ingest_resumes(resumes)
        debug_print('Finished Initializing GraphPipeline', start_time)

    def fetch_sample_resumes(self, src, thresh):
        start_time = datetime.datetime.now()
        debug_print('Fetching Sample Resumes', start_time)
        files  = []
        for dirs, _, filenames in os.walk(src):
            for file in filenames:
                if file.endswith('.pdf'):
                    files.append(os.path.join(dirs, file))
        debug_print('Finished Fetching Sample Resumes', start_time)
        return files[:int(len(files)*thresh)]

    def parse_text(self, *args, **kwargs):
        skills = self.sg.parse_text(*args, **kwargs)
        job_titles = self.jtg.parse_text(*args, **kwargs) if self.jtg else []
        custom_job_titles = self.tjtg.parse_text(*args, **kwargs) if self.tjtg else []
        return {
            "skills": skills,
            "job_titles": job_titles,
            "custom_job_titles": custom_job_titles
        }

    def get_siblings(self, *args, **kwargs):
        skill_siblings = self.sg.get_siblings(*args, **kwargs)
        job_title_siblings = self.jtg.get_siblings(*args, **kwargs) if self.jtg else []
        custom_job_title_siblings = self.tjtg.get_siblings(*args, **kwargs) if self.tjtg else []
        return {
            "skill_siblings": skill_siblings,
            "job_title_siblings": job_title_siblings,
            "custom_job_title_siblings": custom_job_title_siblings
        }

    def match_resumes(self, *args, **kwargs):
        return self.rg.match_resumes(*args, **kwargs)

    def store_cache(self, src="app/data/RRC_GraphPipeline.pkl"):
        start_time = datetime.datetime.now()
        debug_print('Storing Cache', start_time)
        with open(src, 'wb') as f:
            pickle.dump(self, f)
        debug_print('Finished Storing Cache', start_time)
        print("Cached graph stored as", src)

def store_cache(graph_pipeline: GraphPipeline, src="app/data/RRC_GraphPipeline.pkl"):
    start_time = datetime.datetime.now()
    debug_print('Storing Cache', start_time)
    with open(src, 'wb') as f:
        pickle.dump(graph_pipeline, f)
    debug_print('Finished Storing Cache', start_time)
    print("Cached graph stored as", src)

def create_and_store_graph_pipeline(src="app/data/RRC_GraphPipeline.pkl", use_custom_job_titles=False) -> GraphPipeline:
    skillspath = r"f:\Aumu's Folder\Programming\projects\jd_cv\LC_Scrapper\lc_skills_dataset_classified_v1"
    job_titles_path = r"F:\Aumu's Folder\Programming\projects\rrc_frontend\rrc\Recruitryte_Clone\14_Resume_Keyword_Search_BSS_UI\recruitryte_responses"
    resumepath = r"F:\Aumu's Folder\Programming\projects\rrc_frontend\rrc\Recruitryte_Clone\Test_Resumes"
    custom_job_titles_path = "app/data/graph_filtered_jtdb.json" if use_custom_job_titles else None
    thresh = 1

    gp = GraphPipeline(skillspath, job_titles_path, resumepath, custom_job_titles_path, thresh)
    store_cache(gp, src)
    return gp

def load_graph_cache(src="app/data/BSS_GraphPipeline_Updated.pkl") -> GraphPipeline:
    start_time = datetime.datetime.now()
    debug_print(f'Loading Graphs with: {src}')
    try:
        with open(src, 'rb') as f:
            obj = pickle.load(f)
        debug_print('Graphs Loaded', start_time)
        return obj
    except (FileNotFoundError, ModuleNotFoundError) as e:
        debug_print(f"Error loading graph cache: {e}")
        return create_and_store_graph_pipeline(src)

if __name__ == "__main__":
    # gp = load_graph_cache()
    gp = create_and_store_graph_pipeline(use_custom_job_titles=True)
    result = gp.parse_text("Looking for a software engineer or project manager.")
    print(result)

    # Test parse_text method
    # debug_print("Testing parse_text method")
    # result = gp.parse_text("Software Developer, java, java developer")
    # skills = result["skills"]
    # job_titles = result["job_titles"]
    # debug_print("Skills: " + str(skills))
    # debug_print("Job Titles: " + str(job_titles))

    # # Test get_siblings method for skills
    # debug_print("Testing get_siblings method for skills")
    # skill_siblings = []
    # for skill in skills:
    #     siblings = gp.sg.get_siblings(skill)
    #     skill_siblings.extend(siblings)
    #     debug_print(f"Siblings for skill '{skill}': {len(siblings)}")
    # debug_print("Total Skill Siblings: " + str(len(skill_siblings)))

    # # Test get_siblings method for job titles
    # debug_print("Testing get_siblings method for job titles")
    # job_title_siblings = []
    # for job_title in job_titles:
    #     siblings = gp.jtg.get_siblings(job_title)
    #     job_title_siblings.extend(siblings)
    #     debug_print(f"Siblings for job title '{job_title}': {len(siblings)}")
    # debug_print("Total Job Title Siblings: " + str(len(job_title_siblings)))

    # # Test match_resumes method
    # debug_print("Testing match_resumes method")
    # bsc = [[skill.lower() for skill in skills], [job_title.lower() for job_title in job_titles]]
    # matching_resumes = gp.match_resumes(bsc)
    # debug_print("Matching Resumes: " + str(len(matching_resumes)))

    # Test store_cache method
    # debug_print("Testing store_cache method")
    # gp.store_cache("./RRC_GraphPipeline_test.pkl")
    # debug_print("Cache stored successfully")
