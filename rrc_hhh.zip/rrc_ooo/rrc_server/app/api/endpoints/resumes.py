from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, Any, List, Tuple
from app.services.graph import GraphPipeline
from collections import Counter

router = APIRouter()

def get_graph_pipeline():
    from app import graph_pipeline
    return graph_pipeline

@router.post("/get-matching-resume")
async def get_matching_resume(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    """
    Endpoint to get matching resumes based on the Boolean Search Combination (BSC).
    The payload must contain 'bsc' as an array of arrays.
    """
    bsc = data.get("bsc", [])

    if not bsc or not isinstance(bsc, list) or not all(isinstance(group, list) for group in bsc):
        raise HTTPException(
            status_code=400,
            detail="Invalid payload. 'bsc' must be a list of lists representing Boolean Search Combinations."
        )

    # Call match_resumes from the GraphPipeline class
    try:
        matching_resumes = gp.match_resumes(bsc)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error during resume matching: {str(e)}")

    # Rank resumes
    resume_scores = rank_resumes(matching_resumes, bsc)
    ranked_resumes = sorted(resume_scores, key=lambda x: x[1], reverse=True)

    return {
        "matching_resumes": [{"resume": resume, "score": score} for resume, score in ranked_resumes]
    }

def rank_resumes(
    matching_resumes: List[Tuple[str, str]],
    bsc: List[List[str]]
) -> List[Tuple[str, float]]:
    """
    Rank resumes based on the number of matching skills.
    The score is calculated as (matched_skills / total_skills in BSC).
    """
    # Flatten BSC for easier comparison
    all_skills = set(skill.lower() for group in bsc for skill in group)

    # Assign scores based on matching
    resume_scores = []
    for resume, filename in matching_resumes:
        # Assuming `resume` contains matched skills or keywords
        matched_skills = Counter()
        for keyword in resume.split():  # Adjust split logic based on your data format
            if keyword.lower() in all_skills:
                matched_skills[keyword.lower()] += 1

        matched_count = len(matched_skills)
        total_count = len(all_skills)
        score = matched_count / total_count if total_count > 0 else 0.0
        resume_scores.append((filename, score))

    return resume_scores
