from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, Any, List
from app.services.graph import GraphPipeline
from pydantic import BaseModel

router = APIRouter()

def get_graph_pipeline():
    from app import graph_pipeline
    return graph_pipeline

class Payload(BaseModel):
    currentlySelectedJobTitles: List[str]
    currentlySelectedSkills: List[str]
    selectedVariations: Dict[str, List[str]]
    currentNumberLabels: List[int]

@router.post("/extract_skills")
async def extract_skills(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    jd_text = data.get("jd_text", "")
    if not jd_text:
        raise HTTPException(status_code=400, detail="jd_text is required.")

    extracted_skills = gp.parse_text(jd_text)["skills"]
    return {"skills": list(extracted_skills)}

@router.post("/get_skill_variations")
async def get_skill_variations(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    skill = data.get("skill")
    if not skill:
        raise HTTPException(status_code=400, detail="Skill is required.")

    variations = gp.get_siblings(skill)["skill_siblings"]
    return {
        "keyword": skill,
        "variations": variations
    }

@router.post("/get_top_skill_variations")
async def get_skill_variations(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    skill = data.get("skill")
    if not skill:
        raise HTTPException(status_code=400, detail="Skill is required.")

    variations = gp.get_siblings(skill)["skill_siblings"]

    # Return only the top 10 variations
    top_variations = variations[:10]

    return {
        "skill": skill,
        "variations": top_variations
    }

@router.post("/generate_bss")
async def generate_bss(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    selected_skills = data.get("selected_skills", [])
    selected_job_titles = data.get("selected_job_titles", [])
    selected_variations = data.get("selected_variations", {})
    num_of_keyword_variations = data.get("num_of_keyword_variations", [0, 3, 5])

    num_of_keyword_variations = sorted(set(num_of_keyword_variations))
    pipeline_config = {
        "top_pipeline_variations": num_of_keyword_variations[0],
        "middle_pipeline_variations": num_of_keyword_variations[min(1, len(num_of_keyword_variations) - 1)],
        "bottom_pipeline_variations": num_of_keyword_variations[-1],
    }

    async def get_auto_variations(skills: List[str], num_variations: int) -> Dict[str, List[str]]:
        auto_variations = {}
        for skill in skills:
            response = await get_skill_variations({"skill": skill}, gp)
            fetched_variations = response["variations"][:num_variations]

            user_selected_variations = selected_variations.get(skill, [])
            all_variations = list(set(fetched_variations + user_selected_variations))
            auto_variations[skill] = all_variations

        return auto_variations

    def create_bss_and_bsc(skills: List[str], job_titles: List[str], variations: Dict[str, List[str]]) -> Dict[str, Any]:
        bss_parts = []
        bsc = [[]]  # Boolean Search Combinations

        if job_titles:
            job_titles_bss = f"({' OR '.join(job_titles)})"
            bss_parts.append(job_titles_bss)

        for skill in skills:
            if skill in variations:
                skill_variations = variations[skill]
                bss_parts.append(f"({skill} OR {' OR '.join(skill_variations)})")

                new_bsc = []
                skill_variations.insert(0, skill)
                for variation in skill_variations:
                    for combo in bsc:
                        new_bsc.append(combo + [variation])
                bsc = new_bsc
            else:
                bss_parts.append(skill)
                for combo in bsc:
                    combo.append(skill)

        bss = " AND ".join(bss_parts)
        return {"bss": bss, "bsc": bsc, "bss_count": len(bss)}

    pipeline_1 = create_bss_and_bsc(
        selected_skills, selected_job_titles, selected_variations
    )

    middle_pipeline_variations = await get_auto_variations(
        selected_skills, pipeline_config["middle_pipeline_variations"]
    )
    pipeline_2 = create_bss_and_bsc(
        selected_skills, selected_job_titles, middle_pipeline_variations
    )

    bottom_pipeline_variations = await get_auto_variations(
        selected_skills, pipeline_config["bottom_pipeline_variations"]
    )
    pipeline_3 = create_bss_and_bsc(
        selected_skills, selected_job_titles, bottom_pipeline_variations
    )

    return {
        "top_pipeline": pipeline_1,
        "middle_pipeline": pipeline_2,
        "bottom_pipeline": pipeline_3,
    }


@router.get("/test")
async def test():
    return "Hello"


@router.post("/generate_strings_from_jd")
async def generate_strings_from_jd(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    jd_text = data.get("jd_text", "")
    if not jd_text:
        raise HTTPException(status_code=400, detail="jd_text is required.")

    extracted_skills = gp.parse_text(jd_text).get("skills", [])
    extracted_job_titles = gp.parse_text(jd_text).get("job_titles", [])

    def get_frequent_items(items: List[str], limit: int) -> List[str]:
        frequency = {item: jd_text.lower().count(item.lower()) for item in items}
        sorted_items = sorted(frequency.items(), key=lambda x: x[1], reverse=True)
        return [item[0] for item in sorted_items[:limit]]

    # apply limits
    selected_skills = get_frequent_items(extracted_skills, 5) if len(extracted_skills) > 5 else extracted_skills
    selected_job_titles = get_frequent_items(extracted_job_titles, 2) if len(extracted_job_titles) > 2 else extracted_job_titles

    # get variations only for selected items
    skill_variations = {
        skill: gp.get_siblings(skill)["skill_siblings"][:10] for skill in selected_skills
    }
    job_title_variations = {
        title: gp.get_siblings(title)["job_title_siblings"][:10] for title in selected_job_titles
    }

    def create_bss_and_bsc(
        skills: List[str],
        job_titles: List[str],
        variations: Dict[str, List[str]],
        include_title_variations: bool = False
    ) -> Dict[str, Any]:
        bss_parts = []
        bsc = [[]]  # Boolean Search Combinations

        # handle job titles: combine with OR, optionally use OR for variations
        if job_titles:
            title_parts = []
            for title in job_titles:
                title_variations = variations.get(title, []) if include_title_variations else []
                if title_variations:
                    title_parts.append(f"({title} OR {' OR '.join(title_variations)})")
                else:
                    title_parts.append(title)

            # combine job titles with OR
            bss_parts.append(f"({' OR '.join(title_parts)})")

            # update BSC for titles
            new_bsc = []
            for combo in bsc:
                for title in job_titles:
                    title_variations = variations.get(title, []) if include_title_variations else []
                    variations_to_use = [title] + title_variations
                    for variation in variations_to_use:
                        new_bsc.append(combo + [variation])
            bsc = new_bsc

        # handle skills: combine with AND but use OR for variations
        for skill in skills:
            skill_variations = variations.get(skill, [])
            if skill_variations:
                bss_parts.append(f"({skill} OR {' OR '.join(skill_variations)})")

                new_bsc = []
                skill_variations.insert(0, skill)
                for variation in skill_variations:
                    for combo in bsc:
                        new_bsc.append(combo + [variation])
                bsc = new_bsc
            else:
                bss_parts.append(skill)
                for combo in bsc:
                    combo.append(skill)

        # combine job titles with OR and skills with AND
        bss = " AND ".join(bss_parts)
        return {"bss": bss, "bsc": bsc, "char_count": len(bss)}


    # generate pipelines
    pipeline_1 = create_bss_and_bsc(
        selected_skills, selected_job_titles, {skill: skill_variations.get(skill, [])[:0] for skill in selected_skills}
    )
    pipeline_2 = create_bss_and_bsc(
        selected_skills, selected_job_titles, {skill: skill_variations.get(skill, [])[:2] for skill in selected_skills}
    )
    pipeline_3 = create_bss_and_bsc(
        selected_skills, selected_job_titles, {skill: skill_variations.get(skill, [])[:4] for skill in selected_skills},
        include_title_variations=True
    )

    # Return response
    return {
        "extracted_job_titles": extracted_job_titles,
        "extracted_skills": extracted_skills,
        "top_ten_job_title_variations": job_title_variations,
        "top_ten_skill_variations": skill_variations,
        "default_keys": {
            "job_titles": selected_job_titles,
            "skills": selected_skills
        },
        "bss_pipeline_1": pipeline_1, # short length strings
        "bss_pipeline_2": pipeline_2, # medium length strings
        "bss_pipeline_3": pipeline_3, # long length strings
    }

@router.post("/generate_strings")
async def generate_strings(payload: Payload, gp: GraphPipeline = Depends(get_graph_pipeline)) -> Dict[str, Any]:
    currentlySelectedJobTitles = payload.currentlySelectedJobTitles
    currentlySelectedSkills = payload.currentlySelectedSkills
    selectedVariations = payload.selectedVariations
    currentNumberLabels = payload.currentNumberLabels

    # Ensure currentNumberLabels is sorted in ascending order
    currentNumberLabels.sort()

    # Initialize pipelines
    pipelines = {0: 0, 1: 3, 2: 5}

    # Assign variations to pipelines based on currentNumberLabels
    if 7 in currentNumberLabels or 10 in currentNumberLabels:
        pipelines[2] = max([label for label in currentNumberLabels if label in [7, 10]])
    if 3 in currentNumberLabels or 5 in currentNumberLabels:
        pipelines[1] = max([label for label in currentNumberLabels if label in [3, 5]])

    # Function to get top variations if not enough provided
    def get_top_variations(item, count):
        user_variations = selectedVariations.get(item, [])[:count]
        additional_variations = gp.get_siblings(item)["skill_siblings" if item in currentlySelectedSkills else "job_title_siblings"][:count]
        return list(dict.fromkeys(user_variations + additional_variations))[:count]

    # Create boolean string for titles and skills
    def create_bss_and_bsc(
        skills: List[str],
        job_titles: List[str],
        variations: Dict[str, List[str]],
        include_title_variations: bool = False
    ) -> Dict[str, Any]:
        bss_parts = []
        bsc = [[]]  # Boolean Search Combinations

        # handle job titles: combine with OR, optionally use OR for variations
        if job_titles:
            title_parts = []
            for title in job_titles:
                title_variations = variations.get(title, []) if include_title_variations else []
                if title_variations:
                    title_parts.append(f"({title} OR {' OR '.join(title_variations)})")
                else:
                    title_parts.append(title)

            # combine job titles with OR
            bss_parts.append(f"{' AND '.join(title_parts)}")

            # update BSC for titles
            new_bsc = []
            for combo in bsc:
                for title in job_titles:
                    title_variations = variations.get(title, []) if include_title_variations else []
                    variations_to_use = [title] + title_variations
                    for variation in variations_to_use:
                        new_bsc.append(combo + [variation])
            bsc = new_bsc

        # handle skills: combine with AND but use OR for variations
        for skill in skills:
            skill_variations = variations.get(skill, [])
            if skill_variations:
                bss_parts.append(f"({skill} OR {' OR '.join(skill_variations)})")

                new_bsc = []
                skill_variations.insert(0, skill)
                for variation in skill_variations:
                    for combo in bsc:
                        new_bsc.append(combo + [variation])
                bsc = new_bsc
            else:
                bss_parts.append(skill)
                for combo in bsc:
                    combo.append(skill)

        # combine job titles with OR and skills with AND
        bss = " AND ".join(bss_parts)
        return {"bss": bss, "bsc": bsc, "bss_count": len(bss)}

    # Generate pipelines
    pipeline_1 = create_bss_and_bsc(
        currentlySelectedSkills, currentlySelectedJobTitles, {**{skill: get_top_variations(skill, pipelines[0]) for skill in currentlySelectedSkills}, **{title: get_top_variations(title, pipelines[0]) for title in currentlySelectedJobTitles}}
    )
    pipeline_2 = create_bss_and_bsc(
        currentlySelectedSkills, currentlySelectedJobTitles, {**{skill: get_top_variations(skill, pipelines[1]) for skill in currentlySelectedSkills}, **{title: get_top_variations(title, pipelines[1]) for title in currentlySelectedJobTitles}}
    )
    pipeline_3 = create_bss_and_bsc(
        currentlySelectedSkills, currentlySelectedJobTitles, {**{skill: get_top_variations(skill, pipelines[2]) for skill in currentlySelectedSkills}, **{title: get_top_variations(title, pipelines[2]) for title in currentlySelectedJobTitles}},
        include_title_variations=True
    )

    # Return response
    return {
        "bss_pipeline_1": pipeline_1,  # short length strings
        "bss_pipeline_2": pipeline_2,  # medium length strings
        "bss_pipeline_3": pipeline_3,  # long length strings
    }