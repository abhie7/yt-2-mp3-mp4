import re
import os
import csv
from pdfminer.high_level import extract_text
from pdfminer.pdfparser import PDFSyntaxError
from docx import Document
# from docx2pdf import convert
# import nltk
from nltk.corpus import stopwords

# nltk.download('stopwords')

class DocumentParser:
    def __init__(self, filepath):
        self.filepath = filepath

    def get_cleaned_text(self):
        ext = os.path.splitext(self.filepath)[-1].lower()
        text = ""

        try:
            if ext == '.pdf':
                text = self.extract_pdf_text()
            elif ext == '.docx':
                text = self.convert_docx_to_text()
            elif ext == '.doc':
                text = self.convert_doc_to_text()

            text = self.clean_text(text)
            text = self.remove_stopwords(text)
        except Exception as e:
            print(f"\nError processing {self.filepath}: {e}")

        return text

    def extract_pdf_text(self):
        try:
            text = extract_text(self.filepath)
            return text
        except (PDFSyntaxError) as e:
            print(f"\nError extracting text from {self.filepath}: {e}")
            return ""

    def convert_docx_to_text(self):
        try:
            doc = Document(self.filepath)
            text = "\n".join([para.text for para in doc.paragraphs])
            return text
        except Exception as e:
            print(f"\nError extracting text from {self.filepath}: {e}")
            return ""

    def convert_doc_to_text(self):
        try:
            docx_text = self.convert_doc_to_docx(self.filepath)
            return docx_text
        except Exception as e:
            print(f"\nError converting .doc to .docx for {self.filepath}: {e}")
            return ""

    @staticmethod
    def convert_doc_to_docx(doc_file):
        doc = Document(doc_file)
        text = ""
        for para in doc.paragraphs:
            text += para.text + "\n"
        return text

    @staticmethod
    def clean_text(text):
        text = re.sub(r"\n+", " ", text)  # Replace multiple newlines with a space
        text = re.sub(r"[^\w\s/#@._+\-/\\-]", ' ', text)  # Remove special characters
        text = re.sub(r"\s{2,}", " ", text)  # Replace multiple spaces with a single space
        text = re.sub(r"[•\t▪➢❖]", '', text)  # Remove specific bullet points and characters
        text = text.strip()
        return text.lower()

    @staticmethod
    def remove_stopwords(text):
        stop_words = set(stopwords.words('english'))
        words = text.split()  # Split the text into words
        words = [word for word in words if word.lower() not in stop_words]  # Remove stopwords
        return ' '.join(words)

def main(directory):
    for file in os.listdir(directory):
        if file.endswith(('.pdf', '.doc', '.docx')):
            file_path = os.path.join(directory, file)
            parser = DocumentParser(file_path)
            cleaned_text = parser.get_cleaned_text()
            if cleaned_text:
                print(f"Parsed text from {file}: {cleaned_text[:100]}...")  # Print first 100 characters for preview
            else:
                print(f"Failed to parse {file}.\n")

if __name__ == '__main__':
    main('/home/alois/Abhiraj/6. Resume Parser Model/og_respa_data_collection/test_resumes')
