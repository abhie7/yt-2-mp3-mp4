from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.responses import JSONResponse, FileResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from typing import List, Dict, Any
# from pymongo import MongoClient
from collections import Counter
from graph import GraphPipeline, load_graph_cache

app = FastAPI()

# Initialize the GraphPipeline
gp = load_graph_cache()

# MongoDB client (commented out as in the original code)
# client = MongoClient("mongodb://192.168.2.178:27017/")
# db = client["keyword_variations_india_jd"]
# skills_variations_collection = db["job_title_keywords_test_groups"]

# Template rendering
templates = Jinja2Templates(directory="templates")

@app.get("/")
async def index(request: Request):
    return templates.TemplateResponse("index1.html", {"request": request})

@app.post("/extract_skills")
async def extract_skills(data: Dict[str, Any]):
    jd_text = data.get("jd_text", "")
    if not jd_text:
        raise HTTPException(status_code=400, detail="jd_text is required.")
    
    extracted_skills = gp.parse_text(jd_text)
    return {"skills": list(extracted_skills)}

@app.post("/get_skill_variations")
async def get_skill_variations(data: Dict[str, Any]):
    skill = data.get("skill")
    if not skill:
        raise HTTPException(status_code=400, detail="Skill is required.")
    
    # Mock implementation
    variations = gp.get_siblings(skill)

    return {
        "job_titles": [],
        "keywords": [],
        "variations": variations
    }

@app.post("/add_skill_variation")
async def add_skill_variation(data: Dict[str, Any]):
    # Implement as needed
    return {"success": False, "error": "Not implemented."}

@app.post("/generate_bss")
async def generate_bss(data: Dict[str, Any]):
    selected_skills = data.get("selected_skills", [])
    variations = data.get("variations", {})

    bss_parts = []
    bsc = [[]]  # Boolean search combinations

    for skill in selected_skills:
        if skill in variations:
            skill_variations = variations[skill]
            bss_parts.append(f"({skill} OR {' OR '.join(skill_variations)})")

            new_bsc = []
            skill_variations.insert(0, skill)
            for skill_variation in skill_variations:
                for partial_bsc in bsc:
                    new_bsc.append(partial_bsc + [skill_variation])
            bsc = new_bsc
        else:
            for i in range(len(bsc)):
                bsc[i].append(skill)
            bss_parts.append(skill)

    bss = " AND ".join(bss_parts)
    return {"bss": bss, "bsc": bsc}

@app.post("/get-matching-resume")
async def get_matching_resume(data: Dict[str, Any]):
    selected_skills = data.get("selected_skills", [])
    variations = data.get("variations", {})
    bsc = [[]]  # Boolean search combinations

    for skill in selected_skills:
        if skill in variations:
            skill_variations = variations[skill]
            new_bsc = []
            skill_variations.insert(0, skill)
            for skill_variation in skill_variations:
                for partial_bsc in bsc:
                    new_bsc.append(partial_bsc + [skill_variation])
            bsc = new_bsc
        else:
            for i in range(len(bsc)):
                bsc[i].append(skill)

    resumes = gp.match_resumes(bsc)
    return {"resumes": resumes}

@app.get("/file-view")
async def file_view(filepath: str):
    if not filepath:
        raise HTTPException(status_code=400, detail="File path is required.")
    
    try:
        # You may add path sanitization here
        return FileResponse(filepath)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")

# Run using: uvicorn filename:app --reload --host 0.0.0.0 --port 6969
