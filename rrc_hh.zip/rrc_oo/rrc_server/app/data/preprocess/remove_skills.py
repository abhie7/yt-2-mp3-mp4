import json
from app.services.job_titles import job_title_keywords
import os

directory = "/home/alois/Abhiraj/Recruitryte_Antariksh/recruitRyteSkillsScrapper/recruitryte_responses"

def filter_job_titles(data):
    """
    Filters jobMetadata.titles to remove entries whose 'value' doesn't match the keywords.
    """
    if "jobMetadata" in data and "titles" in data["jobMetadata"]:
        titles = data["jobMetadata"]["titles"]
        # Filter titles based on keywords
        filtered_titles = [
            title for title in titles
            if any(keyword in title["value"].lower() for keyword in job_title_keywords)
        ]
        data["jobMetadata"]["titles"] = filtered_titles
    return data

def process_json_files(input_dir):
    """
    Process all JSON files in the directory, filter the data, and update the JSON files.
    """
    for file_name in os.listdir(input_dir):
        if file_name.endswith(".json"):
            file_path = os.path.join(input_dir, file_name)
            try:
                # Read the JSON file
                with open(file_path, "r") as f:
                    data = json.load(f)
                
                # Filter the data
                filtered_data = filter_job_titles(data)
                
                # Save the filtered data back to the file
                with open(file_path, "w") as f:
                    json.dump(filtered_data, f, indent=4)
                
                print(f"Processed and updated: {file_name}")
            
            except json.JSONDecodeError as e:
                print(f"Error decoding {file_name}: {e}")
            except Exception as e:
                print(f"Error processing {file_name}: {e}")

# Process the JSON files
process_json_files(directory)
