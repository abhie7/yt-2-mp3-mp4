from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from app.services.graph import load_graph_cache, GraphPipeline

# Define FastAPI app with a lifespan for initialization
@asynccontextmanager
async def lifespan(app: FastAPI):
    global graph_pipeline
    graph_pipeline = load_graph_cache()  # Load the graph cache
    print("GraphPipeline initialized and loaded into cache.")
    yield
    print("Shutting down GraphPipeline...")

app = FastAPI(lifespan=lifespan)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # Frontend origin
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods
    allow_headers=["*"],  # Allow all headers
)

# Import and include routers
from app.api.endpoints import skills, resumes, job_titles

app.include_router(skills.router, prefix="/api", tags=["skills"])
app.include_router(resumes.router, prefix="/api", tags=["resumes"])
app.include_router(job_titles.router, prefix="/api", tags=["job_titles"])

# Global variable to store the GraphPipeline instance
graph_pipeline = None
