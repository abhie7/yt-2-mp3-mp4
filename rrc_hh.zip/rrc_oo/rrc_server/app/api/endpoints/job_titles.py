from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, Any
from app.services.graph import GraphPipeline

router = APIRouter()

def get_graph_pipeline():
    from app import graph_pipeline
    return graph_pipeline

@router.post("/extract_job_titles")
async def extract_job_titles(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    jd_text = data.get("jd_text", "")
    if not jd_text:
        raise HTTPException(status_code=400, detail="jd_text is required.")

    extracted_job_titles = gp.parse_text(jd_text)["job_titles"]
    return {"job_titles": list(extracted_job_titles)}

@router.post("/get_job_title_variations")
async def get_job_title_variations(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    job_title = data.get("job_title")
    if not job_title:
        raise HTTPException(status_code=400, detail="Job title is required.")

    variations = gp.get_siblings(job_title)["job_title_siblings"]
    # print(f"Job title: {job_title}, Variations: {variations}")  # Add logging
    return {
        "job_title": job_title,
        "variations": variations
    }

@router.post("/get_top_job_title_variations")
async def get_top_job_title_variations(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    job_title = data.get("job_title")
    if not job_title:
        raise HTTPException(status_code=400, detail="Job title is required.")

    variations = gp.get_siblings(job_title)["job_title_siblings"]

    # Return only the top 10 variations
    top_variations = variations[:10]

    return {
        "job_title": job_title,
        "variations": top_variations
    }