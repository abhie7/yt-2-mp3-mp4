from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, Any
from app.services.graph import GraphPipeline

router = APIRouter()

def get_graph_pipeline():
    from app import graph_pipeline
    return graph_pipeline

@router.post("/get-matching-resume")
async def get_matching_resume(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    selected_skills = data.get("selected_skills", [])
    variations = data.get("variations", {})
    bsc = [[]]

    for skill in selected_skills:
        if skill in variations:
            skill_variations = variations[skill]
            new_bsc = []
            skill_variations.insert(0, skill)
            for skill_variation in skill_variations:
                for partial_bsc in bsc:
                    new_bsc.append(partial_bsc + [skill_variation])
            bsc = new_bsc
        else:
            for i in range(len(bsc)):
                bsc[i].append(skill)

    matching_resumes = gp.match_resumes(bsc)
    return {"matching_resumes": matching_resumes, "bsc": bsc}