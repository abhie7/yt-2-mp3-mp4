from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, Any, List
from app.services.graph import GraphPipeline

router = APIRouter()

def get_graph_pipeline():
    from app import graph_pipeline
    return graph_pipeline

@router.post("/extract_skills")
async def extract_skills(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    jd_text = data.get("jd_text", "")
    if not jd_text:
        raise HTTPException(status_code=400, detail="jd_text is required.")

    extracted_skills = gp.parse_text(jd_text)["skills"]
    return {"skills": list(extracted_skills)}

@router.post("/get_skill_variations")
async def get_skill_variations(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    skill = data.get("skill")
    if not skill:
        raise HTTPException(status_code=400, detail="Skill is required.")

    variations = gp.get_siblings(skill)["skill_siblings"]
    return {
        "keyword": skill,
        "variations": variations
    }

@router.post("/get_top_skill_variations")
async def get_skill_variations(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    skill = data.get("skill")
    if not skill:
        raise HTTPException(status_code=400, detail="Skill is required.")

    variations = gp.get_siblings(skill)["skill_siblings"]

    # Return only the top 10 variations
    top_variations = variations[:10]

    return {
        "skill": skill,
        "variations": top_variations
    }


@router.post("/generate_bss")
async def generate_bss(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
    # Extract data from the request
    selected_skills = data.get("selected_skills", [])
    selected_job_titles = data.get("selected_job_titles", [])  # New field
    selected_variations = data.get("selected_variations", {})
    num_of_keyword_variations = data.get("num_of_keyword_variations", [0, 3, 5])

    # Sort and deduplicate variation counts
    num_of_keyword_variations = sorted(set(num_of_keyword_variations))
    pipeline_config = {
        "top_pipeline_variations": num_of_keyword_variations[0],
        "middle_pipeline_variations": num_of_keyword_variations[min(1, len(num_of_keyword_variations) - 1)],
        "bottom_pipeline_variations": num_of_keyword_variations[-1],
    }

    async def get_auto_variations(skills: List[str], num_variations: int) -> Dict[str, List[str]]:
        auto_variations = {}
        for skill in skills:
            response = await get_skill_variations({"skill": skill}, gp)
            fetched_variations = response["variations"][:num_variations]

            # Ensure user-selected variations are included
            user_selected_variations = selected_variations.get(skill, [])
            all_variations = list(set(fetched_variations + user_selected_variations))
            auto_variations[skill] = all_variations

        return auto_variations

    def create_bss_and_bsc(skills: List[str], job_titles: List[str], variations: Dict[str, List[str]]) -> Dict[str, Any]:
        bss_parts = []
        bsc = [[]]  # Boolean Search Combinations

        # Add job titles as part of the search string
        if job_titles:
            job_titles_bss = f"({' OR '.join(job_titles)})"
            bss_parts.append(job_titles_bss)

        # Process skills and their variations
        for skill in skills:
            if skill in variations:
                skill_variations = variations[skill]
                bss_parts.append(f"({skill} OR {' OR '.join(skill_variations)})")

                # Generate combinations
                new_bsc = []
                skill_variations.insert(0, skill)
                for variation in skill_variations:
                    for combo in bsc:
                        new_bsc.append(combo + [variation])
                bsc = new_bsc
            else:
                # If no variations, add the skill directly
                bss_parts.append(skill)
                for combo in bsc:
                    combo.append(skill)

        bss = " AND ".join(bss_parts)
        return {"bss": bss, "bsc": bsc, "bss_count": len(bss)}

    # Top Pipeline - Custom data provided by user
    top_pipeline_data = create_bss_and_bsc(
        selected_skills, selected_job_titles, selected_variations
    )

    # Middle Pipeline - Auto variations
    middle_pipeline_variations = await get_auto_variations(
        selected_skills, pipeline_config["middle_pipeline_variations"]
    )
    middle_pipeline_data = create_bss_and_bsc(
        selected_skills, selected_job_titles, middle_pipeline_variations
    )

    # Bottom Pipeline - More variations
    bottom_pipeline_variations = await get_auto_variations(
        selected_skills, pipeline_config["bottom_pipeline_variations"]
    )
    bottom_pipeline_data = create_bss_and_bsc(
        selected_skills, selected_job_titles, bottom_pipeline_variations
    )

    return {
        "top_pipeline": top_pipeline_data,
        "middle_pipeline": middle_pipeline_data,
        "bottom_pipeline": bottom_pipeline_data,
    }
