from fastapi import APIRouter

router = APIRouter()

from app.api.endpoints import skills, resumes, job_titles  # Import endpoints
router.include_router(skills.router)
router.include_router(resumes.router)
router.include_router(job_titles.router)