import React, { useState, useEffect } from "react"
import Button from "react-bootstrap/Button"
import Container from "react-bootstrap/Container"
import Modal from "react-bootstrap/Modal"
import Dropdown from "react-bootstrap/Dropdown"
import Form from "react-bootstrap/Form"
import {
  getSkillVariations,
  getJobTitleVariations,
} from "../../api/extractItems"
import PropTypes from "prop-types"

function VariationModal({ type, items, show, onHide, onVariationSelect }) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedFilter, setSelectedFilter] = useState(items[0] || "")
  const [variations, setVariations] = useState([])
  const [selectedVariations, setSelectedVariations] = useState([])

  useEffect(() => {
    const fetchVariations = async () => {
      if (selectedFilter) {
        try {
          let response
          if (type === "skills") {
            response = await getSkillVariations(selectedFilter)
          } else if (type === "jobTitles") {
            response = await getJobTitleVariations(selectedFilter)
          }
          setVariations(response.variations)
        } catch (error) {
          console.error("Error fetching variations:", error)
        }
      }
    }

    fetchVariations()
  }, [selectedFilter, type])

  const handleVariationChange = (variation) => {
    setSelectedVariations((prev) =>
      prev.includes(variation)
        ? prev.filter((item) => item !== variation)
        : [...prev, variation]
    )
  }

  const handleSave = () => {
    onVariationSelect(selectedFilter, selectedVariations)
    onHide()
  }

  const filteredData = variations.filter((item) =>
    item.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const [dropdownFilter, setDropdownFilter] = useState("")
  const filteredDropdownItems = items.filter((item) =>
    item.toLowerCase().includes(dropdownFilter.toLowerCase())
  )

  return (
    <Modal
      aria-labelledby='contained-modal-title-vcenter'
      size='xl'
      show={show}
      onHide={onHide}
    >
      <Modal.Header
        className='d-flex align-items-center modal-header'
        closeButton
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            width: "100%",
            alignItems: "center",
          }}
        >
          <Modal.Title
            id='contained-modal-title-vcenter'
            className='custom-title'
          >
            {type === "skills" ? "Keyword" : "Job Title"} Variations
          </Modal.Title>

          <div className='d-flex align-items-center'>
            <Dropdown>
              <Dropdown.Toggle
                className='filter me-3 my-auto d-flex gap-3 align-items-center'
                variant='primary'
                id='dropdown-custom-components'
              >
                {selectedFilter || "Select Keyword/Job Title"}
              </Dropdown.Toggle>

              <Dropdown.Menu>
                <div className='dropdown-search-wrapper'>
                  <Form.Control
                    autoFocus
                    placeholder='Type to filter...'
                    className='mx-3 my-2 w-auto search-bar'
                    key='direction'
                    onChange={(e) => setDropdownFilter(e.target.value)}
                    value={dropdownFilter}
                  />
                  <Dropdown.Divider />
                </div>

                <div className='dropdown-items-wrapper'>
                  {filteredDropdownItems.map((item, index) => (
                    <Dropdown.Item
                      className='dropdown-item px-2 py-1'
                      key={index}
                      onClick={() => {
                        setSelectedFilter(item)
                        setDropdownFilter("")
                      }}
                    >
                      {item}
                    </Dropdown.Item>
                  ))}
                </div>
              </Dropdown.Menu>
            </Dropdown>

            <Form.Control
              type='text'
              placeholder='Search variations...'
              className='me-3 search-bar'
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </Modal.Header>
      <Modal.Body>
        <Container className='scrollable-container p-0'>
          {filteredData.length > 0 ? (
            <div className='custom-grid'>
              {filteredData.map((item, index) => (
                <div
                  key={index}
                  className='d-inline-flex align-items-center label-font rounded p-2 custom-checkbox-wrapper'
                >
                  <label
                    className='custom-checkbox-container d-flex align-items-center'
                    style={{ cursor: "pointer" }}
                  >
                    <input
                      type='checkbox'
                      className='custom-checkbox'
                      checked={selectedVariations.includes(item)}
                      onChange={() => handleVariationChange(item)}
                    />
                    <span className='custom-checkbox-checkmark'></span>
                    <p className='custom-checkbox-label p-0 m-0 w-75'>{item}</p>
                  </label>
                </div>
              ))}
            </div>
          ) : (
            <p>
              No variations available. Please select a keyword or job title
              using the filter beside the search bar to see the variations here.
              If you are unable to see any items in the filter, make you paste a
              good JD and then click the Generate Button to extract job titles
              and keywords.
            </p>
          )}
        </Container>
      </Modal.Body>
      <Modal.Footer className='d-flex justify-content-between'>
        <div>
          Total variations: <b>{variations.length}</b>
        </div>
        <Button onClick={handleSave}>Save</Button>
      </Modal.Footer>
    </Modal>
  )
}

VariationModal.propTypes = {
  type: PropTypes.string.isRequired,
  items: PropTypes.array.isRequired,
  show: PropTypes.bool.isRequired,
  onHide: PropTypes.func.isRequired,
  onVariationSelect: PropTypes.func.isRequired,
}

export default VariationModal
