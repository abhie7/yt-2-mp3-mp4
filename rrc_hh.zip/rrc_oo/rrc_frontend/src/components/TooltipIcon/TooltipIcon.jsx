import React from "react"
import PropTypes from "prop-types"
import OverlayTrigger from "react-bootstrap/OverlayTrigger"
import Tooltip from "react-bootstrap/Tooltip"

const TooltipIcon = ({
  iconClass,
  tooltipText,
  placement,
  children,
  style,
  onClick,
}) => {
  return (
    <OverlayTrigger
      placement={placement}
      overlay={
        <Tooltip
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: "0.75rem",
            fontWeight: "700",
            position: "fixed",
          }}
        >
          {tooltipText}
        </Tooltip>
      }
    >
      <span
        className={`tooltip-icon-container ${iconClass} text-custom-primary`}
        style={{ cursor: onClick ? "pointer" : "default", ...style, cursor: "pointer" }}
        onClick={onClick}
      >
        {children}
      </span>
    </OverlayTrigger>
  )
}

TooltipIcon.propTypes = {
  iconClass: PropTypes.string,
  tooltipText: PropTypes.string.isRequired,
  placement: PropTypes.string,
  children: PropTypes.node,
  style: PropTypes.object,
  onClick: PropTypes.func,
}

export default TooltipIcon
