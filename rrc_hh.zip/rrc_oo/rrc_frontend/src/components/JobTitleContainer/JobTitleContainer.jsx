import React, { useState, useEffect } from "react"
import DynamicListContainer from "../DynamicListContainer/DynamicListContainer"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import VariationModal from "../Modal/Modal"
import {
  getTopJobTitleVariations,
  getJobTitleVariations,
} from "../../api/extractItems"

function JobTitleContainer({
  jobTitles,
  onSelectionChange,
  onVariationSelect,
}) {
  const [selectedJobTitles, setSelectedJobTitles] = useState([])
  const [variations, setVariations] = useState({})
  const [modalShow, setModalShow] = useState(false)
  const [selectedItems, setSelectedItems] = useState([])

  useEffect(() => {
    onSelectionChange(selectedItems)
  }, [selectedItems])

  const handleSelectionChange = (items) => {
    setSelectedItems(items)
  }

  const handleVariationClick = async (jobTitle) => {
    if (!variations[jobTitle]) {
      const response = await getJobTitleVariations(jobTitle)
      setVariations((prev) => ({ ...prev, [jobTitle]: response.variations }))
      onVariationSelect(jobTitle, response.variations)
    }
  }

  return (
    <div className='d-flex align-items-start flex-nowrap'>
      <p className='mb-0 flex-shrink-0 container-title custom-title'>
        Job Titles:&nbsp;
        <TooltipIcon
          iconClass='bi-question-circle'
          tooltipText='Select the job titles relevant to your search. These titles will be included in the Boolean string to broaden the search for similar roles. You can add or remove job titles by checking the boxes.'
          placement='bottom'
        />
      </p>
      {jobTitles.length > 0 ? (
        <DynamicListContainer
          className='flex-grow-1 ms-2 me-2'
          items={jobTitles}
          placeholder='Add job title...'
          tooltipText='Add job title'
          onSelectionChange={handleSelectionChange}
        />
      ) : (
        <div className='d-flex flex-grow-1 ms-2'>
          <span className='placeholder-text'>
            Extracted job titles will be displayed here...
          </span>
        </div>
      )}
      <>
        <TooltipIcon
          iconClass='bi-database-fill-add modal-btn text-light rounded'
          tooltipText='View Related Job Titles'
          placement='left'
          onClick={() => setModalShow(true)}
        />
        <VariationModal
          show={modalShow}
          onHide={() => setModalShow(false)}
          items={jobTitles}
          type='jobTitles'
          onVariationSelect={onVariationSelect}
        />
      </>
    </div>
  )
}

export default JobTitleContainer
