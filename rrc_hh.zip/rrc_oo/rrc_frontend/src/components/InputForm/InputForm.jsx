import React from "react"
import PropTypes from "prop-types"
import TooltipIcon from "../TooltipIcon/TooltipIcon"

const InputForm = ({ jdText, setJdText }) => {
  return (
    <div className='jd-input container p-3 rounded'>
      <form>
        <div className='mb-3 d-flex align-items-center'>
          <label className='me-2 container-title' htmlFor='textarea-input'>
            Generate Boolean Strings
          </label>
          <TooltipIcon
            iconClass='bi-question-circle'
            tooltipText='Enter the job description here. The text should outline the primary responsibilities, required skills, and qualifications for the position. Highlight key phrases and keywords to improve Boolean string generation.'
            placement={"right"}
          />
        </div>
        <textarea
          id='textarea-input'
          type='textarea'
          value={jdText}
          onChange={(e) => setJdText(e.target.value)}
          placeholder="Enter your prompt or Paste the entire job description text - Exclude the 'About Company' section, but include the job title."
          className='textarea-input form-control'
        />
      </form>
    </div>
  )
}

InputForm.propTypes = {
  jdText: PropTypes.string.isRequired,
  setJdText: PropTypes.func.isRequired,
}

export default InputForm
