import React from "react"

const BooleanStringDisplay = ({ booleanString, title }) => {
  const formatBooleanString = (str) => {
    const regex = /(".*?"|\(|\)|AND|OR)/g
    return str.split(regex).map((item, index) => {
      if (item === "AND" || item === "OR") {
        return (
          <span key={index} className='boolean-operator'>
            {item}
          </span>
        )
      } else if (item === "(" || item === ")") {
        return (
          <span key={index} className='boolean-parenthesis'>
            {item}
          </span>
        )
      } else if (item.trim() !== "") {
        return (
          <span key={index} className='boolean-item'>
            {item}
          </span>
        )
      } else {
        return null
      }
    })
  }

  return (
    <div className='boolean-string-container'>
      <h3>{title}</h3>
      <p className='boolean-string'>{formatBooleanString(booleanString)}</p>
    </div>
  )
}

export default BooleanStringDisplay
