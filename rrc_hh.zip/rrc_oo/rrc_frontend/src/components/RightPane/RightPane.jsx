import React from "react"
import NumberLabels from "../NumberLabels/NumberLabels"
import BooleanStringContainer from "../BooleanStringContainer/BooleanStringContainer"
import Divider from "../Divider/Divider"
import JobTitleContainer from "../JobTitleContainer/JobTitleContainer"
import KeywordsContainer from "../KeywordsContainer/KeywordsContainer"
import XraySearch from "../XraySearch/XraySearch"

function RightPane({
  extractedSkills,
  extractedJobTitles,
  skillVariations,
  jobTitleVariations,
  booleanStrings,
  selectedLabels,
  onJobTitleSelectionChange,
  onKeywordSelectionChange,
  onLabelSelectionChange,
  onVariationSelect,
  onBooleanStringChange,
}) {
  return (
    <div className='right-pane-container flex-grow-1'>
      <JobTitleContainer
        jobTitles={extractedJobTitles}
        onSelectionChange={onJobTitleSelectionChange}
        onVariationSelect={onVariationSelect}
      />
      <Divider />
      <KeywordsContainer
        keywords={extractedSkills}
        onSelectionChange={onKeywordSelectionChange}
        onVariationSelect={onVariationSelect}
      />
      <Divider />
      <NumberLabels onSelectionChange={onLabelSelectionChange} />
      <Divider />
      <XraySearch booleanString={booleanStrings[0]} />
      <BooleanStringContainer
        booleanStrings={booleanStrings}
        selectedSkills={[...extractedJobTitles, ...extractedSkills]}
        selectedVariations={{ ...skillVariations, ...jobTitleVariations }}
        numOfKeywordVariations={Math.max(...selectedLabels)} // Use the maximum value from selectedLabels
        onBooleanStringChange={onBooleanStringChange}
      />
    </div>
  )
}

export default RightPane
