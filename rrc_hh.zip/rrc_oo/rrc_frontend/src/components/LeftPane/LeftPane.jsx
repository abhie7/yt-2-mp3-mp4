import React, { useState } from "react"
import InputForm from "../InputForm/InputForm"
import Button from "../Button/Button"
import {
  extractSkills,
  extractJobTitles,
  getTopSkillVariations,
  getTopJobTitleVariations,
} from "../../api/extractItems"

function LeftPane({
  setExtractedSkills,
  setExtractedJobTitles,
  setSkillVariations,
  setJobTitleVariations,
}) {
  const [jdText, setJdText] = useState("")

  const handleGenerateBooleanStrings = async () => {
    try {
      const skillsResponse = await extractSkills(jdText)
      const jobTitlesResponse = await extractJobTitles(jdText)
      console.log("Extracted Skills:", skillsResponse.skills)
      console.log("Extracted Job Titles:", jobTitlesResponse.job_titles)
      setExtractedSkills(skillsResponse.skills)
      setExtractedJobTitles(jobTitlesResponse.job_titles)

      // Fetch skill variations
      const skillVariationsPromises = skillsResponse.skills.map((skill) =>
        getTopSkillVariations(skill)
      )
      const skillVariationsResponses = await Promise.all(
        skillVariationsPromises
      )
      const skillVariations = skillsResponse.skills.reduce((acc, skill, index) => {
        acc[skill] = skillVariationsResponses[index].variations
        return acc
      }, {})
      console.log("Top Skill Variations:", skillVariations)
      setSkillVariations(skillVariations)

      // Fetch job title variations
      const jobTitleVariationsPromises = jobTitlesResponse.job_titles.map(
        (jobTitle) => getTopJobTitleVariations(jobTitle)
      )
      const jobTitleVariationsResponses = await Promise.all(
        jobTitleVariationsPromises
      )
      const jobTitleVariations = jobTitlesResponse.job_titles.reduce((acc, jobTitle, index) => {
        acc[jobTitle] = jobTitleVariationsResponses[index].variations
        return acc
      }, {})
      console.log("Top Job Title Variations:", jobTitleVariations)
      setJobTitleVariations(jobTitleVariations)
    } catch (error) {
      console.error("Error extracting data:", error)
    }
  }

  return (
    <>
      <InputForm jdText={jdText} setJdText={setJdText} />
      <div className='button-group d-flex gap-2'>
        <Button
          text='Clear'
          color='secondary'
          onClick={() => setJdText("")}
          width='30%'
        />
        <Button
          text='Generate Boolean Strings&nbsp;'
          color='primary'
          onClick={handleGenerateBooleanStrings}
          width='70%'
          icon='bi-stars'
        />
      </div>
    </>
  )
}

export default LeftPane