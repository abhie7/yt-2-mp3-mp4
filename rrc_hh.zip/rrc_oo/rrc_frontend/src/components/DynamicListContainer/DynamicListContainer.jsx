import React, { useState } from "react"
import PropTypes from "prop-types"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import AddItemForm from "../AddItemForm/AddItemForm"

function DynamicListContainer({
  items = [],
  placeholder = "Enter item",
  tooltipText = "Add item",
  className = "",
  onSelectionChange,
}) {
  const [itemList, setItemList] = useState(items)
  const [isAdding, setIsAdding] = useState(false)
  const [hoveredIndex, setHoveredIndex] = useState(null)

  const handleRemoveItem = (index) => {
    const updatedList = itemList.filter((_, i) => i !== index)
    setItemList(updatedList)
    onSelectionChange(updatedList)
  }

  const handleAddItem = (newItem) => {
    if (newItem) {
      const updatedList = [...itemList, newItem]
      setItemList(updatedList)
      onSelectionChange(updatedList)
    }
    setIsAdding(false)
  }

  return (
    <div
      className={`dynamic-list-container d-flex flex-wrap gap-2 ${className}`}
    >
      {itemList.map((item, index) => (
        <div
          key={index}
          className='d-inline-flex align-items-center label-font rounded-1 px-1 py-1'
          onMouseEnter={() => setHoveredIndex(index)}
          onMouseLeave={() => setHoveredIndex(null)}
        >
          <label
            className='custom-checkbox-container d-flex align-items-center'
            style={{ cursor: "pointer" }}
          >
            <input type='checkbox' className='custom-checkbox' />
            <span className='custom-checkbox-checkmark me-2'></span>
            <span style={{ lineHeight: 0 }}>{item}</span>
          </label>
          <div
            className='d-flex align-items-center ms-2'
            style={{
              cursor: "pointer",
              width: "1rem",
              height: "1rem",
            }}
            onClick={() => handleRemoveItem(index)}
          >
            {hoveredIndex === index ? (
              <TooltipIcon
                iconClass='bi bi-dash-circle text-danger'
                tooltipText='Remove'
              />
            ) : null}
          </div>
        </div>
      ))}
      <div className='d-inline-add align-items-center'>
        {isAdding ? (
          <AddItemForm onAdd={handleAddItem} placeholder={placeholder} />
        ) : (
          <div onClick={() => setIsAdding(true)}>
            <TooltipIcon
              iconClass='bi-plus-circle'
              tooltipText={tooltipText}
              placement='top'
            />
          </div>
        )}
      </div>
    </div>
  )
}

DynamicListContainer.propTypes = {
  items: PropTypes.arrayOf(PropTypes.string).isRequired,
  placeholder: PropTypes.string,
  tooltipText: PropTypes.string,
  className: PropTypes.string,
  onSelectionChange: PropTypes.func.isRequired,
}

export default DynamicListContainer
