import React, { useState, useEffect } from "react"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import Button from "../Button/Button"

function BooleanStringContainer({
  booleanStrings,
  selectedSkills,
  selectedVariations,
  numOfKeywordVariations,
  onBooleanStringChange,
}) {
  const [editIndex, setEditIndex] = useState(null)
  const [editText, setEditText] = useState("")
  const [pipelines, setPipelines] = useState({})

  const createBssAndBsc = (
    skills,
    variations,
    maxDepth = 5,
    currentDepth = 0
  ) => {
    if (currentDepth >= maxDepth) {
      return { bss: "", bsc: [] }
    }

    const bssParts = []
    let bsc = [[]]

    for (const skill of skills) {
      if (variations[skill] && Array.isArray(variations[skill])) {
        const skillVariations = variations[skill].slice(0, 5) // Limit to 5 variations
        bssParts.push(`(${skill} OR ${skillVariations.join(" OR ")})`)

        const newBsc = []
        for (const variation of skillVariations) {
          for (const combo of bsc) {
            newBsc.push([...combo, variation])
          }
        }
        bsc.push(...newBsc)
      } else {
        bssParts.push(skill)
        for (const combo of bsc) {
          combo.push(skill)
        }
      }
    }

    return { bss: bssParts.join(" AND "), bsc }
  }

  const updatePipelines = () => {
    try {
      const topPipelineData = createBssAndBsc(
        selectedSkills.slice(0, 5),
        selectedVariations,
        3 // Set a lower max depth for top pipeline
      )

      const middlePipelineData = createBssAndBsc(
        selectedSkills,
        selectedVariations,
        4 // Set a moderate max depth for middle pipeline
      )

      const bottomPipelineData = createBssAndBsc(
        selectedSkills,
        selectedVariations,
        5 // Keep full depth for bottom pipeline
      )

      setPipelines({
        top: topPipelineData,
        middle: middlePipelineData,
        bottom: bottomPipelineData,
      })

      if (onBooleanStringChange) {
        onBooleanStringChange([
          topPipelineData.bss,
          middlePipelineData.bss,
          bottomPipelineData.bss,
        ])
      }
    } catch (error) {
      console.error("Error updating pipelines:", error)
      // Handle the error gracefully
      setPipelines({
        top: { bss: "", bsc: [] },
        middle: { bss: "", bsc: [] },
        bottom: { bss: "", bsc: [] },
      })
    }
  }
  useEffect(() => {
    updatePipelines()
  }, [
    selectedSkills,
    selectedVariations,
    numOfKeywordVariations,
    onBooleanStringChange,
  ])

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text)
  }

  const handleSearch = (text) => {
    alert(`Search: ${text}`)
    // Implement search functionality here
  }

  const handleEdit = (index) => {
    setEditIndex(index)
    setEditText(booleanStrings[index])
  }

  const handleSave = (index) => {
    // Save logic here if needed
    setEditIndex(null)
  }

  const formatBooleanString = (booleanString) => {
    const regex = /(".*?"|\(|\)|AND|OR)/g
    return booleanString.split(regex).map((item, index) => {
      if (item === "AND" || item === "OR") {
        return (
          <span key={index} className='boolean-operator'>
            {item}
          </span>
        )
      } else if (item === "(" || item === ")") {
        return (
          <span key={index} className='boolean-parenthesis'>
            {item}
          </span>
        )
      } else if (item.trim() !== "") {
        return (
          <span key={index} className='boolean-item'>
            {item}
          </span>
        )
      } else {
        return null
      }
    })
  }

  const RenderPipelineContainer = (pipelineData, index) => {
    const { bss } = pipelineData || {}

    return (
      <div
        key={index}
        className='boolean-string-container-item position-relative'
      >
        {editIndex === index ? (
          <div className='boolean-string rounded p-2 mb-2'>
            <input
              type='text'
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              className='form-control'
            />
            <Button
              text='Save&nbsp;'
              color='primary'
              onClick={() => handleSave(index)}
              icon='bi-arrow-right'
            />
          </div>
        ) : (
          <div className='boolean-string rounded p-2 mb-2'>
            <p className='me-4'>{formatBooleanString(bss)}</p>
            <div className='button-container'>
              <TooltipIcon
                iconClass='bi bi-copy'
                tooltipText='Copy'
                placement='left'
                className='tooltip-icon-container'
                onClick={() => handleCopy(bss)}
              />
              <TooltipIcon
                iconClass='bi bi-pencil'
                tooltipText='Edit String'
                placement='left'
                className='tooltip-icon-container'
                onClick={() => handleEdit(index)}
              />
              <TooltipIcon
                iconClass='bi bi-search'
                tooltipText='Search Profiles based on Boolean Query'
                placement='left'
                className='tooltip-icon-container'
                onClick={() => handleSearch(bss)}
              />
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className='boolean-string-container'>
      <div className='boolean-strings-wrapper px-0'>
        {Object.entries(pipelines).map(([key, pipeline], index) =>
          RenderPipelineContainer(pipeline, index)
        )}
      </div>
    </div>
  )
}

export default BooleanStringContainer
