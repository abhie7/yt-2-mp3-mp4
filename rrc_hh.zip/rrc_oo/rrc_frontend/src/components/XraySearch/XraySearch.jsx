import React from "react"
import {
  FaLinkedin,
  FaAngellist,
  FaGithub,
  FaKaggle,
  FaStackOverflow,
  FaUpwork,
  FaXing,
} from "react-icons/fa6"
import TooltipIcon from "../TooltipIcon/TooltipIcon"

function XraySearch({ booleanString }) {
  const generateGoogleSearchUrl = (platform, searchText) => {
    const templates = {
      angellist: `${searchText} site:angel.co/p/`,
      github: `${searchText} more:p:person site:github.com -site:github.com/*/* -inurl:"gist"`,
      kaggle: `${searchText} -inurl:(data|datasets|general|code|questions|answers|getting) intitle:(Novice|Contributor|Expert|Master|Grandmaster) site:kaggle.com/ -site:kaggle.com/*-*-* -site:kaggle.com/*/*`,
      linkedin: `${searchText} site:linkedin.com/in`,
      stackoverflow: `${searchText} site:stackoverflow.com/users`,
      upwork: `${searchText} site:upwork.com/freelancers`,
      xing: `${searchText} site:xing.com/profile/`,
    }

    return templates[platform]
  }

  const links = [
    { platform: "angellist", text: "AngelList", icon: <FaAngellist /> },
    { platform: "github", text: "GitHub", icon: <FaGithub /> },
    { platform: "kaggle", text: "Kaggle", icon: <FaKaggle /> },
    { platform: "linkedin", text: "LinkedIn", icon: <FaLinkedin /> },
    {
      platform: "stackoverflow",
      text: "Stack Overflow",
      icon: <FaStackOverflow />,
    },
    { platform: "upwork", text: "Upwork", icon: <FaUpwork /> },
    { platform: "xing", text: "Xing", icon: <FaXing /> },
  ]

  return (
    <div className='d-flex align-items-center flex-nowrap'>
      <p className='mb-0 flex-shrink-0 container-title custom-title'>
        X-ray Search:&nbsp;
        <TooltipIcon
          iconClass='bi-question-circle'
          tooltipText='Use these links to perform an X-ray search on various platforms.'
          placement='bottom'
        />
      </p>
      <div className='dynamic-list-container d-flex flex-wrap gap-2 ms-2'>
        {links.map((link, index) => (
          <a
            key={index}
            href={`https://www.google.com/search?q=${encodeURIComponent(
              generateGoogleSearchUrl(link.platform, booleanString)
            )}`}
            className='d-inline-flex align-items-center label-links rounded p-2'
            target='_blank'
            rel='noopener noreferrer'
          >
            <TooltipIcon
              iconClass=''
              tooltipText={link.text}
              placement='bottom'
            >
              {link.icon}
            </TooltipIcon>
            <span className='ms-2'>{link.text}</span>
          </a>
        ))}
      </div>
    </div>
  )
}

export default XraySearch
