import React from "react"
import PropTypes from "prop-types"
import Modal from "react-bootstrap/Modal"
import Button from "react-bootstrap/Button"

function ResumeModal({ show, onHide, resumes }) {
  return (
    <Modal show={show} onHide={onHide} size='lg'>
      <Modal.Header closeButton>
        <Modal.Title>Matching Resumes</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {resumes.length > 0 ? (
          <ul>
            {resumes.map((resume, index) => (
              <li key={index}>
                <a
                  href={`http://localhost:6969/file-view?filepath=${resume[0]}`}
                  target='_blank'
                  rel='noopener noreferrer'
                >
                  {resume[1]}
                </a>
              </li>
            ))}
          </ul>
        ) : (
          <p>No matching resumes found.</p>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Button variant='secondary' onClick={onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

ResumeModal.propTypes = {
  show: PropTypes.bool.isRequired,
  onHide: PropTypes.func.isRequired,
  resumes: PropTypes.array.isRequired,
}

export default ResumeModal
