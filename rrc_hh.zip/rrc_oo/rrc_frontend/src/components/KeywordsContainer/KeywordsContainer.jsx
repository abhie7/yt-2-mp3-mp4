import React, { useState, useEffect } from "react"
import DynamicListContainer from "../DynamicListContainer/DynamicListContainer"
import TooltipIcon from "../TooltipIcon/TooltipIcon"
import VariationModal from "../Modal/Modal"
import {
  getTopSkillVariations,
  getSkillVariations,
} from "../../api/extractItems"

function KeywordsContainer({ keywords, onSelectionChange, onVariationSelect }) {
  const [modalShow, setModalShow] = useState(false)
  const [selectedItems, setSelectedItems] = useState([])
  const [variations, setVariations] = useState({})

  useEffect(() => {
    onSelectionChange(selectedItems)
  }, [selectedItems])

  const handleSelectionChange = (items) => {
    setSelectedItems(items)
  }

  const handleVariationClick = async (keyword) => {
    if (!variations[keyword]) {
      const response = await getSkillVariations(keyword)
      setVariations((prev) => ({ ...prev, [keyword]: response.variations }))
      onVariationSelect(keyword, response.variations)
    }
  }

  return (
    <div className='d-flex align-items-start flex-nowrap'>
      <p className='mb-0 flex-shrink-0 container-title custom-title'>
        Keywords:&nbsp;
        <TooltipIcon
          iconClass='bi-question-circle'
          tooltipText="Select the keywords that are important for the job role. These keywords will be included in the Boolean string to refine the search results. You can add more keywords by clicking the '+' button."
          placement='bottom'
        />
      </p>
      {keywords.length > 0 ? (
        <DynamicListContainer
          className='flex-grow-1 ms-2'
          items={keywords}
          placeholder='Add keyword...'
          tooltipText='Add keyword'
          onSelectionChange={handleSelectionChange}
        />
      ) : (
        <div className='d-flex flex-grow-1 ms-2'>
          <span className='placeholder-text'>
            Extracted keywords will be displayed here...
          </span>
        </div>
      )}
      <>
        <TooltipIcon
          iconClass='bi-database-fill-add modal-btn text-light rounded'
          tooltipText='View Related Keywords'
          placement='left'
          onClick={() => setModalShow(true)}
        />
        <VariationModal
          show={modalShow}
          onHide={() => setModalShow(false)}
          items={keywords}
          type='skills'
          onVariationSelect={onVariationSelect}
        />
      </>
    </div>
  )
}

export default KeywordsContainer
