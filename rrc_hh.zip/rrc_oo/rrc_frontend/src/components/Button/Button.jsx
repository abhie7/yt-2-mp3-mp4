import React from "react"
import PropTypes from "prop-types"

const Button = ({
  text,
  icon,
  onClick,
  color = "primary",
  size = "btn-l",
  bold = true,
  width,
}) => {
  return (
    <button
      className={`btn btn-${color} ${size} ${bold ? "fw-bold" : ""}`}
      type='button'
      onClick={onClick}
      style={{ width: width || "auto", fontSize: "0.9rem" }}
    >
      {text}
      {/* {icon && <span>&nbsp;</span>} */}
      {icon && <i className={`bi ${icon}`}></i>}
    </button>
  )
}

Button.propTypes = {
  text: PropTypes.string,
  icon: PropTypes.string,
  onClick: PropTypes.func,
  color: PropTypes.string,
  size: PropTypes.string,
  bold: PropTypes.bool,
  width: PropTypes.string,
}

export default Button
