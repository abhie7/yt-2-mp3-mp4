import React, { useState, useEffect, useCallback } from "react"
import LeftPane from "./LeftPane/LeftPane"
import RightPane from "./RightPane/RightPane"
import { generateBooleanSearchString } from "../api/extractItems"

function MainContent() {
  const [extractedSkills, setExtractedSkills] = useState([])
  const [extractedJobTitles, setExtractedJobTitles] = useState([])
  const [skillVariations, setSkillVariations] = useState({})
  const [jobTitleVariations, setJobTitleVariations] = useState({})
  const [booleanStrings, setBooleanStrings] = useState(["", "", ""])
  const [selectedLabels, setSelectedLabels] = useState([0, 3, 5])

  useEffect(() => {
    const fetchBooleanString = async () => {
      const payload = {
        selected_skills: extractedSkills,
        selected_job_titles: extractedJobTitles,
        variations: {
          ...skillVariations,
          ...jobTitleVariations,
        },
        num_of_keyword_variations: selectedLabels,
      }
      const response = await generateBooleanSearchString(
        payload.selected_skills,
        payload.selected_job_titles,
        payload.variations,
        payload.num_of_keyword_variations
      )
      const newBooleanStrings = ["", "", ""]
      if (selectedLabels.includes(0)) newBooleanStrings[0] = response.bss
      if (selectedLabels.includes(3) || selectedLabels.includes(5))
        newBooleanStrings[1] = response.bss
      if (
        selectedLabels.includes(5) ||
        selectedLabels.includes(7) ||
        selectedLabels.includes(10)
      )
        newBooleanStrings[2] = response.bss
      setBooleanStrings(newBooleanStrings)
    }

    fetchBooleanString()
  }, [
    extractedSkills,
    extractedJobTitles,
    skillVariations,
    jobTitleVariations,
    selectedLabels,
  ])

  const handleJobTitleSelectionChange = (selectedJobTitles) => {
    setExtractedJobTitles(selectedJobTitles)
  }

  const handleKeywordSelectionChange = (selectedKeywords) => {
    setExtractedSkills(selectedKeywords)
  }

  const handleLabelSelectionChange = (selectedLabels) => {
    setSelectedLabels(selectedLabels)
  }

  const handleVariationSelect = (parent, variations) => {
    if (extractedSkills.includes(parent)) {
      setSkillVariations((prev) => ({ ...prev, [parent]: variations }))
    } else if (extractedJobTitles.includes(parent)) {
      setJobTitleVariations((prev) => ({ ...prev, [parent]: variations }))
    }
  }

  const handleBooleanStringChange = useCallback((newBooleanStrings) => {
    setBooleanStrings(newBooleanStrings)
  }, [])

  return (
    <div className='main-content d-flex w-100 h-100'>
      <div className='left-pane '>
        <LeftPane
          setExtractedSkills={setExtractedSkills}
          setExtractedJobTitles={setExtractedJobTitles}
          setSkillVariations={setSkillVariations}
          setJobTitleVariations={setJobTitleVariations}
        />
      </div>

      <div className='right-pane flex-grow-1 h-100 d-flex'>
        <RightPane
          extractedSkills={extractedSkills}
          extractedJobTitles={extractedJobTitles}
          skillVariations={skillVariations}
          jobTitleVariations={jobTitleVariations}
          booleanStrings={booleanStrings}
          selectedLabels={selectedLabels}
          onJobTitleSelectionChange={handleJobTitleSelectionChange}
          onKeywordSelectionChange={handleKeywordSelectionChange}
          onLabelSelectionChange={handleLabelSelectionChange}
          onVariationSelect={handleVariationSelect}
          onBooleanStringChange={handleBooleanStringChange}
        />
      </div>
    </div>
  )
}

export default MainContent
