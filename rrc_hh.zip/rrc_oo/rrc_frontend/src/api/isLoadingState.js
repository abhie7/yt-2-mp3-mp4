// src/utils/useLoadingState.ts

import React, { useState, useEffect } from 'react';

export function useLoadingState(initialLoading = false) {
  const [isLoading, setIsLoading] = useState(initialLoading);

  useEffect(() => {
    // Simulate API call
    const simulateFetch = async () => {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setIsLoading(false);
    };

    simulateFetch();
  }, []);

  return isLoading;
}