const API_BASE_URL = "http://localhost:6969/api"

export const extractSkills = async (jdText) => {
  const response = await fetch(`${API_BASE_URL}/extract_skills`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ jd_text: jdText }),
  })

  return response.json()
}

export const extractJobTitles = async (jdText) => {
  const response = await fetch(`${API_BASE_URL}/extract_job_titles`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ jd_text: jdText }),
  })
  return response.json()
}

export const getSkillVariations = async (skill) => {
  const response = await fetch(`${API_BASE_URL}/get_skill_variations`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ skill }),
  })
  return response.json()
}

export const getJobTitleVariations = async (jobTitle) => {
  const response = await fetch(`${API_BASE_URL}/get_job_title_variations`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ job_title: jobTitle }),
  })
  return response.json()
}

export const getTopSkillVariations = async (skill) => {
  const response = await fetch(`${API_BASE_URL}/get_top_skill_variations`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ skill }),
  })
  return response.json()
}

export const getTopJobTitleVariations = async (jobTitle) => {
  const response = await fetch(`${API_BASE_URL}/get_top_job_title_variations`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ job_title: jobTitle }),
  })
  return response.json()
}

export const generateBooleanSearchString = async (
  selectedSkills,
  selectedJobTitles,
  variations,
  numLabels
) => {
  const maxVariations = Math.max(...numLabels)
  const limitedVariations = {}
  for (const skill in variations) {
    if (Array.isArray(variations[skill])) {
      limitedVariations[skill] = variations[skill].slice(0, maxVariations)
    } else {
      limitedVariations[skill] = []
    }
  }

  const payload = {
    selected_skills: selectedSkills,
    selected_job_titles: selectedJobTitles,
    variations: limitedVariations,
    num_of_keyword_variations: numLabels,
  }

  const response = await fetch(`${API_BASE_URL}/generate_bss`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  })
  return response.json()
}

export const getMatchingResumes = async (selectedSkills, variations) => {
  const response = await fetch(`${API_BASE_URL}/get-matching-resume`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ selected_skills: selectedSkills, variations }),
  })
  return response.json()
}
