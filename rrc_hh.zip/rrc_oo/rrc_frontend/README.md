# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

so now hear my out.

when i click on the generate boolean strings button, i get 4 things:

1. Extracted skills
2. Extracted job titles
3. skill / keyword variations
4. job title variations

so now, i want to populate those in a particular way.

1. populate the extracted skills and the job titles in the DynamicListContainer component
2. populate the variations in their respective variation modal - note: also add a dropdown filter which filters and displays the variation of that particular skill. for example - if skills extracted are python, javascript, and c# -> these are being displayed in the the DynamicListContainer component. and these will also be displayed as filters in the variation modal. by selecting the particular skill or job title, its variations will be displayed.

for the placeholder in the DynamicListContainer, display a string telling - Extracted skills will be displayed here, then also add a bootstrap loader.

also make use of industry standard techniques to manage data fetching and all so that my app stays optimized.

i want to generate a boolean search string using regex, please update my components accordingly.

1. in the job title container component and the keywords container component, if i check and select a particular item, the boolean search string should container should be populated immediately -> in the job titles container if i select "Frontend developer", and in the keywords container i select "javascript" and "node" the boolean search string should become:
   "Frontend Developer" AND "Javascript" AND "Node"

2. when i open the variations modal, i select javascript's variations, and i select a few varitions like "React.js" and "Express" and then i filter to see node's variations and i select "Server-side" and "oop", append the bss using 'OR' and wrap the parent items with round brackets, so the bss will become:
   "Frontend Developer" AND ("Javascript" OR "React.js" OR "Express") AND ("Node" OR "Server-side" OR "oop") -> this way.

3. i used to do this using api endpoint so please optimize my api and the number of api hits it takes ->
   this api takes this payload:
   {
   "selected_skills": ["Frontend Developer", "Javascript", "Node"],
   "variations": {
   "Javascript": ["React.js", "Express"],
   "Node": ["Server-side", "oop"]
   }
   }
   and returns
   {
   "bss": "Frontend Developer AND (Javascript OR React.js OR Express) AND (Node OR Server-side OR oop)",
   "bsc": [
   [
   "Frontend Developer",
   "Javascript",
   "Node"
   ],
   [
   "Frontend Developer",
   "React.js",
   "Node"
   ],
   [
   "Frontend Developer",
   "Express",
   "Node"
   ],
   [
   "Frontend Developer",
   "Javascript",
   "Server-side"
   ],
   [
   "Frontend Developer",
   "React.js",
   "Server-side"
   ],
   [
   "Frontend Developer",
   "Express",
   "Server-side"
   ],
   [
   "Frontend Developer",
   "Javascript",
   "oop"
   ],
   [
   "Frontend Developer",
   "React.js",
   "oop"
   ],
   [
   "Frontend Developer",
   "Express",
   "oop"
   ]
   ]
   }

---

@router.post("/generate_bss")
async def generate_bss(data: Dict[str, Any], gp: GraphPipeline = Depends(get_graph_pipeline)):
selected_skills = data.get("selected_skills", [])
variations = data.get("variations", {})
bss_parts = []
bsc = [[]]

    for skill in selected_skills:
        if skill in variations:
            skill_variations = variations[skill]
            bss_parts.append(f"({skill} OR {' OR '.join(skill_variations)})")
            new_bsc = []
            skill_variations.insert(0, skill)
            for skill_variation in skill_variations:
                for partial_bsc in bsc:
                    new_bsc.append(partial_bsc + [skill_variation])
            bsc = new_bsc
        else:
            for i in range(len(bsc)):
                bsc[i].append(skill)
            bss_parts.append(skill)

    bss = " AND ".join(bss_parts)
    return {"bss": bss, "bsc": bsc}

I need to implement a feature for generating boolean strings based on extracted skills and titles. Below are the detailed specifications and requirements:
Overview

- Number Labels: The number labels represent keyword variations. Users can select from the following options: 0, 3, 5, 7, 10.
- Three Pipelines for Boolean Strings:

  1. Top Pipeline (the top most container): Used for 0 variations. It should include only some keywords and titles. By default, select a few parent keywords and one parent title.
  2. Middle Pipeline: Designed for 3-5 variations. It should display the same number of parent keywords but allow multiple variations for each keyword. If the user selects 5, show 5 variations of the keyword.
  3. Bottom Pipeline (the bottom most container): For 5, 7, or 10 variations. It should maintain the same number of parent keywords but include many variations. By default, show 5 variations, and if the user selects 7 or 10, increase the number of displayed variations accordingly.

- Default Selection: When keywords and titles are extracted, the system should automatically select some parent keywords and one parent title for the top pipeline.
- Variation Modal: The variation modal must reflect the selected keywords and their variations. Users should be able to see which keywords are currently selected.
- Dynamic Boolean String Updates: If a user unselects a parent keyword/title or a variation, that item should be removed from the boolean search string immediately.
- API Pipeline Updates: Redesign the /generate_bss endpoint to provide 3 different pipelines of responses in a large json or to create 3 endpoints for displaying boolean search strings (BSS) instead of just one.
